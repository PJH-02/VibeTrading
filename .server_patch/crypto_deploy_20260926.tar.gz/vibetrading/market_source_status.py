"""Fail-closed external market-data entitlement registry.

These entries are deliberately not collectors. A verified, documented free API
and the account entitlement must be recorded before a job may be enabled.
"""

SOURCES = {
    "ES": {"status": "FREE_API_UNVERIFIED", "realtime": False, "enabled": False,
           "reason": "KIS CME live feed requires paid market-data entitlement; CME delayed web quotes are not a documented free collection API"},
    "NQ": {"status": "FREE_API_UNVERIFIED", "realtime": False, "enabled": False,
           "reason": "KIS CME live feed requires paid market-data entitlement; CME delayed web quotes are not a documented free collection API"},
    "NASDAQ_COMPOSITE": {"status": "FREE_API_UNVERIFIED", "enabled": False,
                         "reason": "official symbol, automated access terms and zero fee are unverified"},
    "SP500_CASH": {"status": "FREE_API_UNVERIFIED", "enabled": False,
                    "reason": "official symbol, automated access terms and zero fee are unverified"},
    "KOSPI200_FOREIGN_INTRADAY": {"status": "FUTURES_SOURCE_UNVERIFIED", "enabled": False,
                                 "reason": "KIS domestic-stock investor flow is not a KOSPI200 futures foreign flow"},
    "KOSPI200_FOREIGN_FINAL": {"status": "KRX_OFFICIAL_API_UNAVAILABLE", "enabled": False,
                              "reason": "documented KRX Open API investor-specific futures buy/sell endpoint not identified"},
    "KOSPI200_NIGHT_FUTURES": {"status": "FREE_ENTITLEMENT_UNVERIFIED", "enabled": False,
                               "reason": "KIS night futures channels exist but free entitlement and contract/session schedule need verification"},
}


def source_status() -> dict[str, dict]:
    return {key: dict(value) for key, value in SOURCES.items()}
