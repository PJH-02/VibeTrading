from __future__ import annotations

import asyncio
import logging
import shutil
import time
import json
import sqlite3
from decimal import Decimal
from dataclasses import replace
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

import aiohttp
import psutil

from .bus import NatsJetStreamBus
from .health import check as health_check
from .health import configured_crypto_providers
from .session_alerts import SESSIONS, session_state
from .settings import RuntimeSettings, get_settings
from .status import runtime_status
from .sqlite_store import RuntimeStore

logger = logging.getLogger(__name__)


class TelegramController:
    """Minimal allowlisted control/observability loop; inactive without credentials."""

    def __init__(self, settings: RuntimeSettings | None = None) -> None:
        self.settings = settings or get_settings()
        self.token = self.settings.env.get("TELEGRAM_BOT_TOKEN")
        self.allowed_id = str(self.settings.telegram_user_id or "")
        self.base_url = f"https://api.telegram.org/bot{self.token}" if self.token else ""
        self._offset = 0
        self._sent_session: set[str] = set()
        self._crypto_alerted: set[str] = set()
        self._crypto_alert_at: dict[str, float] = {}

    @property
    def enabled(self) -> bool:
        return bool(self.token and self.allowed_id)

    async def run(self, poll_seconds: int = 25) -> None:
        if not self.enabled:
            logger.warning("Telegram controller disabled: TELEGRAM_BOT_TOKEN/TELEGRAM_USER_ID missing")
            return
        timeout = aiohttp.ClientTimeout(total=poll_seconds + 10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            bus = NatsJetStreamBus(self.settings)
            await bus.connect()
            try:
                await asyncio.gather(
                    self._poll_loop(session, poll_seconds),
                    self._event_bridge(session, bus),
                    self._session_loop(session),
                    self._crypto_health_loop(session),
                    self._mock_notifications_loop(session),
                )
            finally:
                await bus.close()

    async def _poll_loop(self, session: aiohttp.ClientSession, poll_seconds: int) -> None:
        failures=0
        while True:
            try:
                response = await self._api(session, "getUpdates", {"timeout": poll_seconds, "offset": self._offset})
            except (asyncio.TimeoutError,aiohttp.ClientConnectionError) as exc:
                failures+=1
                logger.warning('Telegram polling will retry (%s)',type(exc).__name__)
                await asyncio.sleep(min(30,2**min(failures,5)))
                continue
            except aiohttp.ClientResponseError as exc:
                if exc.status!=429 and exc.status<500: raise
                failures+=1
                logger.warning('Telegram polling will retry status=%s',exc.status)
                await asyncio.sleep(min(30,2**min(failures,5)))
                continue
            failures=0
            for update in response.get("result", []):
                self._offset = max(self._offset, int(update.get("update_id", 0)) + 1)
                await self._handle(session, update)

    async def _event_bridge(self, session: aiohttp.ClientSession, bus: NatsJetStreamBus) -> None:
        # Never consume the high-volume market-data subjects here.  A single
        # catch-all consumer can get buried behind ticks and then discard
        # collector lifecycle events as "old" before Telegram sees them.
        # Operational subjects have independent durable cursors so a market
        # burst cannot delay alerts or order/signal notifications.
        subjects = ("system.>", "signal.>", "order.>", "md.data_gap.>")
        await asyncio.gather(*(
            self._event_bridge_subject(session, bus, subject, f"telegram-event-bridge-{index}")
            for index, subject in enumerate(subjects)
        ))

    async def _event_bridge_subject(self, session: aiohttp.ClientSession, bus: NatsJetStreamBus, subject: str, durable: str) -> None:
        async for message in bus.subscribe(subject, durable=durable, batch=100):
            data = message.data
            provider = str(data.get('provider') or '')
            if provider.endswith('-perp') and provider not in configured_crypto_providers(self.settings):
                await message.ack()
                continue
            # A durable bridge may be recreated after a long outage.  Do not
            # replay historical market ticks into Telegram; storage consumers
            # retain the complete history in Parquet.
            kind = str(data.get("kind") or data.get("event_type") or "")
            if message.subject.startswith("md.trade.") or message.subject.startswith("md.order_book.") or message.subject.startswith("md.index_quote."):
                # Market data is stored in Parquet, not pushed to Telegram.
                await message.ack()
                continue
            elif message.subject.startswith("md.data_gap"):
                kind = "gap"
            elif message.subject.startswith("signal."):
                kind = "signal"
            elif message.subject.startswith("order."):
                destination = str(data.get("destination", "")).lower()
                # Timefolio intents are operationally important even before
                # submission; real-account notifications exclude blocked and
                # pre-submit records.
                if destination == "timefolio":
                    kind = "timefolio_intent"
                elif destination == "real" and str(data.get("status", "")).lower() not in {"created", "blocked"}:
                    kind = "execution"
                else:
                    await message.ack()
                    continue
            elif message.subject.startswith("system."):
                kind = str(data.get("kind") or "system")
                if kind not in {"collector_start", "collector_stop", "collector_error", "storage_error", "compactor_error"}:
                    await message.ack()
                    continue
            else:
                await message.ack(); continue
            # Operational events must not be dropped merely because the
            # market-data bridge was behind. They are isolated now, so a
            # bounded replay window safely prevents stale deployment-era
            # errors from being delivered as current incidents.
            ts_ns = int(data.get("created_ts_ns") or data.get("event_ts_ns") or data.get("ts_ns") or 0)
            try:
                max_age_seconds = max(60, int(self.settings.env.get("TELEGRAM_EVENT_MAX_AGE_SECONDS", "300")))
            except ValueError:
                max_age_seconds = 300
            if ts_ns and time.time_ns() - ts_ns > max_age_seconds * 1_000_000_000:
                await message.ack()
                continue
            try:
                provider = str(data.get("provider") or "")
                if kind == "collector_error" and provider in configured_crypto_providers(self.settings):
                    await self._crypto_issue(session, provider, str(data.get("error") or "수집 오류"))
                elif kind == "collector_start" and provider in configured_crypto_providers(self.settings):
                    await self._crypto_recovered(session, provider)
                else:
                    await self._send(session, self.allowed_id, self._format_event(kind, data))
            except aiohttp.ClientResponseError as exc:
                # Telegram allows only a small outbound rate.  A throttled
                # notification is intentionally dropped; the market event is
                # already durable in NATS/Parquet and should not block acks.
                if exc.status != 429:
                    logger.warning("Telegram event push failed subject=%s status=%s", message.subject, exc.status)
            except Exception:
                logger.exception("Telegram event push failed subject=%s", message.subject)
            await message.ack()

    async def _crypto_issue(self, session: aiohttp.ClientSession, provider: str, reason: str) -> None:
        if provider not in configured_crypto_providers(self.settings):
            return
        now = time.monotonic()
        if now - self._crypto_alert_at.get(provider, -1e9) < 300:
            return
        name = provider.split("-", 1)[0].title()
        await self._send(session, self.allowed_id, f"🚨 {name} 선물 수집 오류\n{reason[:180]}\n재연결 상태는 status로 확인")
        self._crypto_alerted.add(provider)
        self._crypto_alert_at[provider] = now

    async def _crypto_recovered(self, session: aiohttp.ClientSession, provider: str) -> None:
        if provider not in configured_crypto_providers(self.settings):
            self._crypto_alerted.discard(provider)
            self._crypto_alert_at.pop(provider,None)
            return
        if provider in self._crypto_alerted:
            await self._send(session, self.allowed_id, f"✅ {provider.split('-', 1)[0].title()} 선물 수집 복구")
            self._crypto_alerted.discard(provider)
            self._crypto_alert_at.pop(provider, None)

    async def _crypto_health_loop(self, session: aiohttp.ClientSession) -> None:
        while True:
            try:
                group = health_check(self.settings, "crypto-collectors", 90)
                # An absent heartbeat means the optional crypto profile is off.
                if group.get("reason") != "heartbeat_missing":
                    for provider in configured_crypto_providers(self.settings):
                        if provider not in group.get("providers", []):
                            continue
                        worker = health_check(self.settings, f"collectors-{provider}", 90)
                        if float(group.get("age_seconds") or 0) > 90:
                            await self._crypto_issue(session, provider, "코인 수집기 응답 없음")
                        elif worker.get("state") == "error" or worker.get("phase") == "paused":
                            await self._crypto_issue(session, provider, str(worker.get("reason") or "수집 중단"))
                        elif float(worker.get("age_seconds") or 0) > 90:
                            await self._crypto_issue(session, provider, "수집 상태 갱신 중단")
                        elif worker.get("phase") == "publishing" and float(worker.get("event_age_seconds") or 0) <= 90:
                            await self._crypto_recovered(session, provider)
            except Exception:
                logger.exception("Telegram crypto health alert check failed")
            await asyncio.sleep(30)

    def _compact_status(self) -> str:
        now = datetime.now(ZoneInfo("Asia/Seoul")).strftime("%m/%d %H:%M")
        workers = {name: health_check(self.settings, name, 120 if name != "maintenance" else 420)
                   for name in ("collectors", "storage", "maintenance")}
        healthy = sum(bool(item.get("ok")) for item in workers.values())
        memory = psutil.virtual_memory()
        used_gib = (memory.total - memory.available) / 1024**3
        available_gib = memory.available / 1024**3
        disk = shutil.disk_usage(self.settings.data_root)
        crypto = health_check(self.settings, "crypto-collectors", 90)
        crypto_expected = crypto.get("reason") != "heartbeat_missing"
        profile_running = crypto_expected and float(crypto.get("age_seconds", 1e9)) <= 90
        if crypto_expected:
            crypto_settings = replace(self.settings, state_dir=self.settings.data_root / "crypto_state")
            crypto_storage = health_check(crypto_settings, "crypto-storage", 120)
            crypto_archive = health_check(crypto_settings, "maintenance", 420)
            crypto_services_ok = bool(crypto_storage.get("ok") and crypto_archive.get("ok"))
            crypto_service_line = (f"코인 저장 {'정상' if crypto_storage.get('ok') else '오류'}"
                                   f" · 보관 {'정상' if crypto_archive.get('ok') else '오류'}")
        else:
            crypto_services_ok = True
            crypto_service_line = "코인 저장·보관: 중지"
        venue_lines: list[str] = []
        live_symbols: set[str] = set()
        all_venues_collecting = True
        for provider in configured_crypto_providers(self.settings):
            venue = provider.split('-',1)[0].title()
            worker = health_check(self.settings, f"collectors-{provider}", 90) if profile_running else {}
            if not profile_running or provider not in crypto.get("providers", []):
                label = "중지"
            elif not worker.get("ok"):
                label = "오류" if worker.get("state") == "error" else "응답 없음"
            elif worker.get("phase") != "publishing":
                label = "연결 중"
            elif float(worker.get("event_age_seconds") or 0) > 90:
                label = "데이터 지연"
            else:
                seen = worker.get("symbol_last_seen_ns") or {}
                symbols = sorted(symbol for symbol, ts in seen.items()
                                 if symbol in {"BTCUSDT", "ETHUSDT", "SOLUSDT"}
                                 and time.time_ns() - int(ts) <= 120 * 1_000_000_000)
                live_symbols.update(symbols)
                label = ", ".join(symbols) if symbols else "연결됨 · 종목 확인 중"
            if label != "BTCUSDT, ETHUSDT, SOLUSDT":
                all_venues_collecting = False
            venue_lines.append(f"{venue}: {label}")
        overall = "정상" if healthy == 3 and available_gib >= 0.5 and crypto_services_ok and (not crypto_expected or (profile_running and all_venues_collecting)) else "주의"
        domestic_lines=[]
        from .universe_config import configured_symbols
        for provider,label in [('kis','KIS'),('kiwoom','Kiwoom'),('toss','TOSS')]:
            worker=health_check(self.settings,'collectors-'+provider,120)
            phase=worker.get('phase','')
            fresh=sorted(s for s,ts in (worker.get('symbol_last_seen_ns') or {}).items()
                if time.time_ns()-int(ts)<=120_000_000_000)
            if phase=='market_closed': state='장 종료'
            elif not worker.get('ok'): state='오류/응답 없음'
            elif phase=='paused': state='일시 중지'
            elif fresh: state='수집 정상'
            elif phase in {'connecting','recovering'}: state='연결/복구 중'
            else: state='최근 수신 없음'
            if state not in {'수집 정상','장 종료'}: overall='주의'
            configured=', '.join(configured_symbols(provider)) or ('근월·차근월 선물' if provider=='kis' else '없음')
            domestic_lines.append(f'{label}: {state}\n  최근 수신: {", ".join(fresh) or "없음"}\n  설정: {configured}')
        return "\n".join((
            f"📊 서버 {overall} · {now} KST",
            f"서비스 {healthy}/3 정상 · 메모리 {used_gib:.1f}/{memory.total / 1024**3:.1f} GiB (가용 {available_gib:.1f})",
            f"저장공간 {(disk.total - disk.free) / 1024**3:.1f}/{disk.total / 1024**3:.1f} GiB",
            crypto_service_line,
            '국내·미국 수집기 (최근 120초 실제 수신):',
            *domestic_lines,
            "코인 무기한 선물:",
            *venue_lines,
            f"실제 수집 종목: {', '.join(sorted(live_symbols)) if live_symbols else '없음'}",
        ))

    def _pending_mock_notifications(self):
        path=self.settings.state_dir/'etf-mock'/'journal.sqlite3'
        if not path.exists(): return []
        with sqlite3.connect(f'file:{path}?mode=ro',uri=True,timeout=.5) as db:
            if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='notifications'").fetchone(): return []
            return [{'id':r[0],'kind':r[1],'payload':json.loads(r[2])} for r in
                db.execute('SELECT id,kind,payload FROM notifications WHERE sent_ns IS NULL ORDER BY created_ns LIMIT 50')]

    def _mark_mock_notification(self, identity):
        with sqlite3.connect(self.settings.state_dir/'etf-mock'/'journal.sqlite3',timeout=.5) as db:
            db.execute('UPDATE notifications SET sent_ns=? WHERE id=? AND sent_ns IS NULL',(time.time_ns(),identity))

    @staticmethod
    def _format_mock_notification(kind, data):
        side='매수' if data.get('side')=='buy' else '매도'
        if kind=='mock_order':
            price='시장가' if data['order_type']=='market' else f"지정가 {Decimal(data['price']):,.0f}원"
            return f"[KIS 모의 주문 접수 · {data.get('account_scope','mock')}]\n{data['strategy']} · {data['symbol']} {side} {data['quantity']}주\n{price}\n주문번호 {data['order_number']}"
        if kind=='mock_fill':
            state='전량 체결' if data['complete'] else '부분 체결'
            return f"[KIS 모의 {state} · {data.get('account_scope','mock')}]\n{data['strategy']} · {data['symbol']} {side} {data['filled_quantity']}주\n체결가 {Decimal(data['fill_price']):,.2f}원\n누적 {data['total_filled']}/{data['ordered_quantity']}주 · 주문번호 {data['order_number']}"
        if kind=='mock_assumed':
            stamp=datetime.fromtimestamp(data['event_ns']/1e9,ZoneInfo('Asia/Seoul')).strftime('%m/%d %H:%M:%S') if data.get('event_ns') else ''
            return f"[전략 평가용 가정 체결 · 실제 체결 아님]\n{data['strategy']} · {data['symbol']} {side} {data['quantity']}주\n가정 시각 {stamp} KST · Best quote {Decimal(data['price']):,.0f}원\n{data['reason']}"
        if kind=='mock_rejected':
            return f"[KIS 모의 주문 거절]\n{data['strategy']} · {data['symbol']} {side} {data['quantity']}주\n{data['reason']}"
        if kind=='mock_daily':
            fees='조회 불가' if data.get('fees') is None else f"{Decimal(data['fees']):,.0f}원"
            positions=', '.join(f'{s} {q}주' for s,q in data['positions'].items()) or '없음'
            text=f"[KIS 모의 장 마감 보고 · {data['day']}]\n실제 계좌 순수익 {Decimal(data['net_pnl']):+,.0f}원\n수수료·제비용(KIS) {fees}\n계좌 평가액 {Decimal(data['equity']):,.0f}원\n미체결 {data['pending_orders']}건 · 보유 {positions}\n순수익 기준: 전일 대비 계좌 평가액 증감(보유 시 평가손익 포함)"
            for scope,account in data.get('accounts',{}).items():
                text+=f"\n{scope} 순수익 {Decimal(account['net_pnl']):+,.0f}원"
            assumed=data.get('assumed')
            if assumed:
                text+=f"\n권한 거절 가정 순수익 {Decimal(assumed['net_pnl']):+,.0f}원 ({assumed['fill_count']}건)\n가정 수수료(추정) {Decimal(assumed['fees']):,.2f}원\n보정 순수익(실제+가정) {Decimal(data['adjusted_net_pnl']):+,.0f}원"
                if data.get('adjusted_fees') is not None: text+=f"\n합산 수수료·제비용 {Decimal(data['adjusted_fees']):,.2f}원"
            if data.get('validation'):
                text+=f"\n실제 합계에 포함된 1주 검증 손익 {Decimal(data['validation']['net_pnl']):+,.0f}원 · 수수료 {Decimal(data['validation']['fees']):,.0f}원"
            return text
        raise ValueError('Unknown mock notification kind')

    async def _deliver_mock_notifications(self, session):
        for row in await asyncio.to_thread(self._pending_mock_notifications):
            await self._send(session,self.allowed_id,self._format_mock_notification(row['kind'],row['payload']))
            await asyncio.to_thread(self._mark_mock_notification,row['id'])

    async def _mock_notifications_loop(self, session):
        while True:
            try: await self._deliver_mock_notifications(session)
            except Exception as exc:
                logger.warning('Mock account notifications deferred; unsent records retained (%s)',type(exc).__name__)
            await asyncio.sleep(1)

    async def _session_loop(self, session: aiohttp.ClientSession) -> None:
        while True:
            for group in SESSIONS:
                active, day = session_state(group)
                state = "OPEN" if active else "CLOSED"
                key = f"{group}:{day}:{state}"
                # Track opens silently, including after restarts. An initial
                # closed observation must not consume today's close notice.
                if active:
                    self._sent_session.add(key)
                elif key not in self._sent_session and f'{group}:{day}:OPEN' in self._sent_session:
                    await self._send(session, self.allowed_id, f"[MARKET {state}] {group} ({day})")
                    self._sent_session.add(key)
            await asyncio.sleep(20)

    @staticmethod
    def _format_event(kind: str, data: dict[str, Any]) -> str:
        if kind == "gap":
            return f"[DATA GAP] provider={data.get('provider')} instrument={data.get('instrument', {}).get('std_symbol', '?')} reason={data.get('reason', '')} seq={data.get('missing_from_sequence')}..{data.get('missing_to_sequence')}"
        if kind == "signal":
            return f"[SIGNAL] {data.get('strategy_id')} {data.get('action')} {data.get('instrument', {}).get('std_symbol', '?')}"
        if kind == "timefolio_intent":
            return f"[TIMEFOLIO INTENT] job={data.get('job_id')} {data.get('side')} {data.get('instrument', {}).get('std_symbol', '?')} status={data.get('status')}"
        if kind == "execution":
            return f"[REAL ORDER] job={data.get('job_id')} {data.get('side')} {data.get('instrument', {}).get('std_symbol', '?')} status={data.get('status')} client={data.get('client_order_id')}"
        if kind == "collector_start":
            return f"[COLLECTOR START] provider={data.get('provider')} symbols={data.get('symbols') or 'auto'}"
        if kind == "collector_stop":
            suffix = f" reason={data.get('reason')}" if data.get("reason") else ""
            return f"[COLLECTOR STOP] provider={data.get('provider')} symbols={data.get('symbols') or 'auto'}{suffix}"
        reason = data.get("error") or data.get("message") or data.get("kind", "")
        cause = f" cause={data.get('cause')}" if data.get("cause") else ""
        failures = data.get("consecutive_failures")
        outage = data.get("outage_seconds")
        state = f" failures={failures} outage={outage}s" if failures is not None else ""
        return f"[COLLECTOR ERROR] provider={data.get('provider', '')} reason={reason}{cause}{state}"

    async def _handle(self, session: aiohttp.ClientSession, update: dict[str, Any]) -> None:
        message = update.get("message") or {}
        sender = str((message.get("from") or {}).get("id", ""))
        if sender != self.allowed_id:
            return
        text = str(message.get("text") or "").strip().lower()
        chat_id = message.get("chat", {}).get("id")
        if text in {"/status", "status"} or text.startswith("/status@"):
            await self._send(session, chat_id, self._compact_status())
        elif text == "/status full":
            await self._send(session, chat_id, str(runtime_status(self.settings)))
        elif text == "/kill confirm":
            store = RuntimeStore(self.settings)
            try:
                store.set_kill_switch("global", True, "telegram", sender)
            finally:
                store.close()
            await self._send(session, chat_id, "global kill switch active")
        elif text == "/restart":
            store = RuntimeStore(self.settings)
            try:
                store.set_kill_switch("global", False, "telegram restart", sender)
            finally:
                store.close()
            await self._send(session, chat_id, "kill switch cleared; workers restart independently")
        elif text in {"/help", "/start"}:
            await self._send(session, chat_id, "status, /status full, /kill confirm, /restart")

    async def _send(self, session: aiohttp.ClientSession, chat_id: Any, text: str) -> None:
        await self._api(session, "sendMessage", {"chat_id": chat_id, "text": text[:3900]})

    async def _api(self, session: aiohttp.ClientSession, method: str, params: dict[str, Any]) -> dict[str, Any]:
        async with session.get(f"{self.base_url}/{method}", params=params) as response:
            response.raise_for_status()
            payload = await response.json()
            if not payload.get("ok"):
                raise RuntimeError(f"Telegram API failed: {payload}")
            return payload
