"""Live Kiwoom ETF signals -> independent books -> KIS mock cash orders.

Entry rules are the frozen C3|vt30|ETF, KP and KD source selections. Confirmed
bars produce decisions; orders go to subsequent available prices. Broker ACK
is never treated as a fill. The long-running loop cannot select a real account.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import logging
import time
import sqlite3
from datetime import datetime
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR

import numpy as np
import pandas as pd
import nats

from .bus import NatsJetStreamBus
from .etf_history import EtfHistory
from .etf_csv_history import ETF_HISTORY_ROLES
from .etf_journal import EtfJournal
from .etf_reference import weights
from .health import touch
from .kis_execution import KisCashBroker, KisOrderRejected, account_permission_rejection
from .models import AssetClass, Bar1mEvent, EventType, InstrumentId, OrderDestination, OrderIntent, Side, Signal, SignalAction, Venue, event_from_dict
from .providers.kiwoom import KiwoomAuthClient, KST
from .settings import get_settings

log = logging.getLogger(__name__)
SYMBOLS = {'069500','122630','114800','252670','229200','233740','251340'}


def intraday_decision(strategy: str, feature: dict, book: dict) -> tuple[int, float, str]:
    """Frozen M1-P stops/sizing and one-entry-per-day selections."""
    direction = int(book['direction']) if book['positions'] else 0
    if direction:
        stop = max(feature['upper_band'],feature['vwap_used']) if direction == 1 else min(feature['lower_band'],feature['vwap_used'])
        if feature['price'] <= stop if direction == 1 else feature['price'] >= stop:
            return 0, 0., 'paper_stop'
        return direction, 0., 'hold'
    if not feature.get('usable') or book['entries']:
        return 0, 0., 'no_entry'
    side = int(feature['entry_signal'])
    if side == 0 or (strategy == 'KP' and side != 1):
        return 0, 0., 'no_entry'
    leverage = min(2. if strategy == 'KP' else 1., .02 / feature['vol14'] * feature['signal_strength'])
    return side, leverage, 'entry'


class EtfTradingLoop:
    def __init__(self):
        self.settings = get_settings()
        self.broker = KisCashBroker(self.settings, mode='mock')
        self.brokers = {'mock':self.broker,'mock2':KisCashBroker(self.settings,mode='mock2')}
        self.kiwoom = KiwoomAuthClient(self.settings)
        root = self.settings.state_dir / 'etf-mock'
        self.journal = EtfJournal(root / 'journal.sqlite3')
        self.history = EtfHistory(self.kiwoom, root / 'warmup')
        self.bus = NatsJetStreamBus(self.settings)
        self.today: dict[str, dict[int, dict]] = {s:{} for s in ETF_HISTORY_ROLES}
        self.quotes: dict[str, tuple[Decimal,Decimal,int]] = {}
        self.features: dict[str, dict] = {}
        self._lock = asyncio.Lock()
        self._day = ''
        self._warmup_task = None
        self.phase = 'starting'
        self._c3_attempt_ns = 0

    def broker_for(self,symbol,scope=None):
        scope=scope or ('mock2' if symbol in {'122630','251340'} else 'mock')
        return self.brokers[scope] if hasattr(self,'brokers') else self.broker

    def intent_quote(self,symbol):
        bid,ask,received=getattr(self,'quotes',{}).get(symbol,(None,None,0))
        return {'bid':str(bid),'ask':str(ask),'received_ns':received,'intent_ns':time.time_ns()} if bid and ask else {}

    def recover_assumptions(self):
        rate=Decimal(self.settings.env.get('ETF_ASSUMED_FEE_RATE','.000148'))
        self.journal.recover_assumptions(rate)

    async def initialize(self):
        states={}
        for scope,broker in self.brokers.items():
            await broker.connect()
            states[scope]=await broker.account_state()
        state=states['mock']
        power = await self.broker.buying_power('069500', Decimal('1'))
        # Divide actual cash balance into thirds. Buying power can already
        # contain a broker haircut; enforce that separately for each order.
        available = Decimal(str(state['summary'].get('dnca_tot_amt') or power['ord_psbl_cash']))
        values = self.broker.client.provider.values
        identity = hashlib.sha256(('mock:'+values['KIS_ACCOUNT_NUMBER']+':01').encode()).hexdigest()
        self.journal.initialize(available, identity)
        secondary=self.brokers['mock2'].client.provider.values
        if secondary['KIS_ACCOUNT_NUMBER']==values['KIS_ACCOUNT_NUMBER']:
            raise RuntimeError('The two mock routes must refer to distinct accounts')
        secondary_id=hashlib.sha256(('mock2:'+secondary['KIS_ACCOUNT_NUMBER']+':01').encode()).hexdigest()
        old=self.journal.db.execute("SELECT value FROM metadata WHERE key='mock2_account_identity'").fetchone()
        if old and old[0]!=secondary_id: raise RuntimeError('Mock2 journal account identity changed')
        self.journal.db.execute('INSERT OR IGNORE INTO metadata VALUES(?,?)',('mock2_account_identity',secondary_id))
        await self.bus.connect(initialize=False)
        # Pending broker fills are reconciled before the aggregate balance check.
        if self.journal.pending():
            await self.reconcile()
            states={scope:await broker.account_state() for scope,broker in self.brokers.items()}
        for scope,state in states.items():
            expected={}
            for book in self.journal.summary().values():
                for symbol,quantity in book['positions'].items():
                    if self.broker_for(symbol) is self.brokers[scope]: expected[symbol]=expected.get(symbol,0)+quantity
            actual={p['pdno']:int(Decimal(p['hldg_qty'])) for p in state['positions'] if int(Decimal(p['hldg_qty']))>0}
            if actual!=expected: raise RuntimeError(f'{scope} broker positions differ from strategy-owned positions')
        self.recover_assumptions()
        self._day = datetime.now(KST).strftime('%Y-%m-%d')
        self.journal.roll_day(self._day)
        self.restore_today(self._day)
        self.phase = 'waiting_session'

    def restore_today(self, day):
        # Intraday deployment must retain the opening minutes used by KP/KD.
        root=self.settings.state_dir/'etf-csv-sync'/'sessions'
        for symbol in self.today:
            path=root/(day+'-'+symbol+'.jsonl')
            if not path.exists(): continue
            for line in path.read_text(encoding='utf-8').splitlines():
                try:
                    row=json.loads(line)
                    timestamp=pd.Timestamp(row['timestamp'])
                    if row['date']!=day or not '09:01'<=timestamp.strftime('%H:%M')<='15:20': continue
                    row['timestamp']=timestamp
                    row['trading_value']=np.nan
                    open_ns=int(timestamp.tz_localize('Asia/Seoul').tz_convert('UTC').value)-60_000_000_000
                    self.today[symbol][open_ns]=row
                except (ValueError,KeyError): continue

    async def prepare(self, day: str):
        self.phase = 'warming_up'
        try:
            await self.history.prepare(day)
            self.phase = 'ready'
        except Exception:
            self.phase = 'warmup_failed'
            log.exception('ETF history preparation failed')

    def fresh_quote(self, symbol: str) -> tuple[Decimal,Decimal]:
        bid, ask, received = self.quotes.get(symbol, (Decimal(0),Decimal(0),0))
        if bid <= 0 or ask <= 0 or bid > ask or time.time_ns()-received > 10_000_000_000:
            raise RuntimeError(f'Fresh valid Kiwoom quote required for {symbol}')
        return bid, ask

    def entry_blocked(self, strategy: str) -> bool:
        """Honor the existing operational kill switch without opening its writer."""
        if (self.settings.state_dir/'etf-mock'/'STOP').exists():
            return True
        path = self.settings.state_dir/'vibetrading.sqlite3'
        if not path.exists():
            return True
        with sqlite3.connect(f'file:{path}?mode=ro',uri=True,timeout=2) as db:
            active = db.execute("SELECT 1 FROM kill_switch WHERE active=1 AND scope IN ('global','account:kis-mock','etf-mock',?) LIMIT 1",(strategy,)).fetchone()
            return bool(active)

    async def place(self, strategy: str, symbol: str, side: Side, quantity: int, identity: str, *, direction: int = 0, safety_stop: float | None = None, auction_market: bool = False):
        broker=self.broker_for(symbol)
        scope='mock2' if symbol in {'122630','251340'} else 'mock'
        # Every signal starts with a limit order. During the closing auction
        # retain the last continuous quote for the initial owned-position exit.
        if auction_market and side == Side.SELL:
            bid, ask, received = self.quotes.get(symbol,(Decimal(0),Decimal(0),0))
            if bid <= 0 or ask < bid or time.time_ns()-received > 90_000_000_000:
                raise RuntimeError('Closing-auction exit needs a valid recent quote')
        else:
            bid, ask = self.fresh_quote(symbol)
        price = ((ask+5)/5).to_integral_value(rounding=ROUND_CEILING)*5 if side == Side.BUY else (max(Decimal(5),bid-5)/5).to_integral_value(rounding=ROUND_FLOOR)*5
        if side == Side.BUY:
            power = await broker.buying_power(symbol, price)
            quantity = min(quantity, int(Decimal(str(power['max_buy_qty']))))
        if quantity <= 0:
            return
        key = hashlib.sha256((identity+':'+symbol+':'+side.value).encode()).hexdigest()
        history_context = self.history.vehicle_reference(symbol) if self.history.day else None
        intent = OrderIntent(intent_id=key,job_id=strategy,signal_id=identity,destination=OrderDestination.REAL,
            instrument=InstrumentId(venue=Venue.KIS,asset_class=AssetClass.ETF,raw_symbol=symbol,std_symbol=symbol,currency='KRW',exchange='KRX'),
            side=side,client_order_id=key[:32],quantity=Decimal(quantity),limit_price=price,
            metadata={'account_mode':'mock','account_scope':scope,'intent_quote':self.intent_quote(symbol),'source_provider':'kiwoom','strategy':strategy,'closing_auction':auction_market,'direction':direction,'safety_stop':safety_stop,
                'vehicle_history':history_context})
        if not self.journal.stage(intent,self._day.replace('-',''),direction,safety_stop):
            return
        try:
            await self.bus.publish_order_intent(intent)
            output = await broker.submit_order(intent)
        except KisOrderRejected as exc:
            self.journal.reject(key,str(exc),permission_failure=account_permission_rejection(exc))
            self.recover_assumptions()
            log.exception('KIS explicitly rejected ETF order')
        except BaseException:
            self.journal.ambiguous(key)
            self.phase = 'order_reconciliation_required'
            raise
        else:
            self.journal.accepted(key, output)
            log.info('KIS mock accepted strategy=%s symbol=%s side=%s qty=%s order=%s',strategy,symbol,side.value,quantity,output.get('ODNO',output.get('odno')))

    async def enter(self, strategy: str, side: int, leverage: float, identity: str, safety_stop: float | None = None):
        if self.entry_blocked(strategy):
            log.warning('ETF entry blocked by kill switch strategy=%s',strategy)
            return
        market = 'KOSPI200' if strategy in {'C3','KP'} else 'KOSDAQ150'
        targets = weights(side,leverage,market)
        # Both signal ETFs and actual leveraged/inverse vehicles must have
        # their own historical series before entering a position.
        for symbol, weight in targets.items():
            if weight > 0:
                self.history.vehicle_reference(symbol)
        book = self.journal.logical_book(strategy)
        if book['entries'] or book['positions'] or self.journal.pending(strategy):
            return
        if self.journal.pending() and any(r['status'] in {'unknown','submitting'} for r in self.journal.pending()):
            raise RuntimeError('Ambiguous order blocks all new entries until reconciled')
        capital = book['cash']-book['reserved']
        signal_symbol = '069500' if market=='KOSPI200' else '229200'
        bid, ask = self.fresh_quote(signal_symbol)
        signal = Signal(signal_id=hashlib.sha256(identity.encode()).hexdigest(),strategy_id=strategy,
            instrument=InstrumentId(venue=Venue.KIWOOM,asset_class=AssetClass.ETF,raw_symbol=signal_symbol,std_symbol=f'KIWOOM:KRX:{signal_symbol}'),
            action=SignalAction.ENTER_LONG if side==1 else SignalAction.ENTER_SHORT,
            event_ts_ns=time.time_ns(),reference_price=(bid+ask)/2,valid_until_ts_ns=time.time_ns()+90_000_000_000,
            source_event_id=identity,metadata={'account_mode':'mock','leverage':leverage,'weights':targets})
        await self.bus.publish_signal(signal)
        planned = []
        for symbol, weight in targets.items():
            if weight <= 0:
                continue
            _, ask = self.fresh_quote(symbol)
            conservative = ((ask+5)/5).to_integral_value(rounding=ROUND_CEILING)*5
            quantity = int(capital*Decimal(str(weight))/(conservative*Decimal('1.005')))
            if quantity:
                planned.append((symbol,quantity))
        for symbol, quantity in planned:
            await self.place(strategy,symbol,Side.BUY,quantity,identity,direction=side,safety_stop=safety_stop)

    async def exit(self, strategy: str, identity: str, *, auction_market: bool = False):
        if self.journal.pending(strategy):
            return
        actual=self.journal.book(strategy)['positions']
        planned=self.journal.logical_book(strategy)['positions']
        for symbol,quantity in planned.items():
            real_quantity=min(quantity,actual.get(symbol,0))
            if real_quantity:
                await self.place(strategy,symbol,Side.SELL,real_quantity,identity,auction_market=auction_market)
        for symbol,quantity in planned.items():
            quantity=max(0,quantity-actual.get(symbol,0))
            if not quantity: continue
            bid,_=self.fresh_quote(symbol)
            key=hashlib.sha256((identity+':assumed:'+symbol).encode()).hexdigest()
            with self.journal.transaction():
                self.journal.assume_fill(key,strategy,symbol,'sell',quantity,bid,self._day,time.time_ns(),
                    'Close position from permission-rejected assumed entry',Decimal(self.settings.env.get('ETF_ASSUMED_FEE_RATE','.000148')))

    async def reconcile(self):
        for order in self.journal.pending():
            broker=self.broker_for(order['symbol'],order['account_scope'])
            if not order['order_number']:
                self.phase = 'order_reconciliation_required'
                # KIS cash orders have no broker client-id idempotency field.
                # Guessing by symbol/time could assign someone else's order.
                continue
            try:
                if order['status']=='pending' and order['order_type']=='limit' and time.time_ns()-(order['accepted_ns'] or order['created_ns']) >= 5_000_000_000 and not order['cancel_requested']:
                    # Persist once before POST: an uncertain cancellation also
                    # needs broker reconciliation, never automatic resubmission.
                    self.journal.db.execute('UPDATE orders SET cancel_requested=1,fallback_requested=1 WHERE intent_id=?',(order['intent_id'],))
                    try:
                        await broker.cancel_order(order['order_number'],order['organization'])
                    except Exception:
                        log.exception('Cancel outcome requires status reconciliation')
                    # Cancellation ACK is not proof that all remaining shares
                    # were cancelled. Read cumulative fills again before market.
                state = await broker.order_status(order['order_number'],day=order['day'],symbol=order['symbol'])
                self.journal.apply_status(order['intent_id'],state)
            except Exception:
                log.exception('KIS fill/cancel reconciliation failed; position remains pending')
        for original in self.journal.fallback_candidates():
            await self.replace_with_market(original)

    async def replace_with_market(self, original: dict):
        """One persistent replacement for the confirmed-cancelled remainder."""
        remaining = original['quantity']-original['filled']
        if remaining <= 0:
            self.journal.db.execute('UPDATE orders SET fallback_done=1 WHERE intent_id=?',(original['intent_id'],))
            return
        previous = OrderIntent.model_validate_json(original['payload'])
        broker=self.broker_for(original['symbol'],original['account_scope'])
        reserve_price = Decimal(0)
        if previous.side == Side.BUY:
            power = await broker.buying_power(original['symbol'],Decimal(0),market=True)
            reserve_price = Decimal(str(power.get('psbl_qty_calc_unpr') or 0))
            if reserve_price <= 0:
                raise RuntimeError('Broker market-buy reservation price is missing; retain replacement plan')
            book = self.journal.book(original['strategy'])
            remaining = min(remaining,int(Decimal(str(power['max_buy_qty']))),int((book['cash']-book['reserved'])/(reserve_price*Decimal('1.005'))))
        else:
            remaining = min(remaining,self.journal.book(original['strategy'])['positions'].get(original['symbol'],0))
        if remaining <= 0:
            self.journal.db.execute('UPDATE orders SET fallback_done=1 WHERE intent_id=?',(original['intent_id'],))
            log.warning('No affordable/owned remainder for market replacement id=%s',original['intent_id'])
            return
        key = hashlib.sha256((original['intent_id']+':market-remainder').encode()).hexdigest()
        replacement = previous.model_copy(update={'intent_id':key,'client_order_id':key[:32],
            'quantity':Decimal(remaining),'limit_price':None,'created_ts_ns':time.time_ns(),
            'metadata':previous.metadata|{'replacement_for':original['intent_id'],'intent_quote':self.intent_quote(original['symbol']),
                'reserve_unit_price':str(reserve_price),'execution':'market_after_5_seconds'}})
        if not self.journal.stage(replacement,original['day'],int(previous.metadata.get('direction',0)),previous.metadata.get('safety_stop'),replacement_for=original['intent_id']):
            return
        try:
            await self.bus.publish_order_intent(replacement)
            output = await broker.submit_order(replacement)
        except KisOrderRejected as exc:
            self.journal.reject(key,str(exc),permission_failure=account_permission_rejection(exc))
            self.recover_assumptions()
            log.exception('KIS rejected market remainder')
        except BaseException:
            self.journal.ambiguous(key)
            self.phase = 'order_reconciliation_required'
            raise
        else:
            self.journal.accepted(key,output)
            log.info('KIS mock market remainder strategy=%s symbol=%s qty=%s',original['strategy'],original['symbol'],remaining)

    async def evaluate_c3(self):
        """Use confirmed native day opens as soon as live trading begins."""
        identity = f'C3:{self._day}:open'
        if self.journal.db.execute('SELECT 1 FROM decisions WHERE id=?',(identity,)).fetchone():
            return
        if time.time_ns()-self._c3_attempt_ns < 2_000_000_000:
            return
        self._c3_attempt_ns = time.time_ns()
        etf = await self.kiwoom.post_api('/api/dostk/stkinfo','ka10001',{'stk_cd':'069500'})
        index = await self.kiwoom.post_api('/api/dostk/sect','ka20001',{'mrkt_tp':'0','inds_cd':'201'})
        etf_open,index_open = abs(float(etf['open_pric'])),abs(float(index['open_pric']))
        if etf_open <= 0 or index_open <= 0:
            return
        leverage,detail = self.history.c3(etf_open,index_open)
        if leverage > 0:
            for symbol,weight in weights(1,leverage,'KOSPI200').items():
                if weight > 0:
                    self.fresh_quote(symbol)
        if self.journal.decision('C3',identity,detail) and leverage > 0:
            await self.enter('C3',1,leverage,identity)

    async def event(self, data: dict):
        event = event_from_dict(data)
        symbol = event.instrument.raw_symbol
        if event.provider != 'kiwoom' or symbol not in SYMBOLS:
            return
        now = datetime.now(KST)
        if event.trading_date != now.strftime('%Y-%m-%d'):
            return
        if event.event_type == EventType.ORDER_BOOK and event.bids and event.asks:
            self.quotes[symbol] = (max(x.price for x in event.bids),min(x.price for x in event.asks),event.receive_ts_ns)
            return
        if event.event_type == EventType.TRADE and symbol=='069500':
            if self.phase=='ready' and event.quantity > 0 and '09:00' <= now.strftime('%H:%M') <= '09:05':
                async with self._lock:
                    try:
                        await self.evaluate_c3()
                    except Exception:
                        log.exception('C3 open signal waiting for native inputs/quotes')
            return
        if event.event_type != EventType.BAR_1M or symbol not in self.today:
            return
        if event.open_ts_ns >= event.close_ts_ns:
            return  # Auction is not a continuous minute signal bar.
        timestamp = pd.Timestamp(event.close_ts_ns,unit='ns',tz='UTC').tz_convert('Asia/Seoul').tz_localize(None)
        if not '09:01' <= timestamp.strftime('%H:%M') <= '15:20':
            return
        self.today[symbol][event.open_ts_ns] = {'timestamp':timestamp,'date':event.trading_date,'symbol':symbol,'source':'KIWOOM',
            **{key:float(getattr(event,key)) for key in ('open','high','low','close','volume')},'trading_value':np.nan}
        if symbol not in {'069500','229200'}:
            return  # Keep vehicle bars; KP/KD signal thresholds use their base ETFs.
        if self.phase != 'ready' or event.ingest_mode != 'realtime' or time.time_ns()-event.close_ts_ns > 120_000_000_000:
            return
        frame = pd.DataFrame(list(self.today[symbol].values())).sort_values('timestamp')
        async with self._lock:
            c3_identity = f'C3:{self._day}:open'
            c3_decided = self.journal.db.execute('SELECT 1 FROM decisions WHERE id=?',(c3_identity,)).fetchone()
            if symbol == '069500' and timestamp.strftime('%H:%M') <= '09:05' and event.volume > 0 and not c3_decided:
                try:
                    await self.evaluate_c3()
                except Exception:
                    log.exception('C3 input/entry not ready')
            strategy = 'KP' if symbol == '069500' else 'KD'
            book = self.journal.logical_book(strategy)
            if strategy == 'KD' and book['positions'] and book['safety_stop'] is not None:
                breached = float(event.close) <= book['safety_stop'] if book['direction']==1 else float(event.close) >= book['safety_stop']
                if breached:
                    await self.exit('KD',f'KD:{event.close_ts_ns}:safety_stop')
                    return
            if timestamp.minute not in {0,30} or timestamp.strftime('%H:%M') > '15:00':
                return
            features = self.history.intraday_features(symbol,frame)
            if features.empty:
                return
            selected = features[features.timestamp == timestamp]
            if selected.empty:
                return
            row = selected.iloc[0].to_dict()
            if not row['usable']:
                return
            direction, leverage, action = intraday_decision(strategy,row,book)
            identity = f'{strategy}:{event.close_ts_ns}:{action}'
            if not self.journal.decision(strategy,identity,{'direction':direction,'leverage':leverage,'action':action}):
                return
            if action == 'entry':
                bid, ask = self.fresh_quote(symbol)
                stop = float((bid+ask)/2)*(1-direction*.25*row['prior_median_range20']) if strategy == 'KD' else None
                if stop is not None and not np.isfinite(stop):
                    return
                await self.enter(strategy,direction,leverage,identity,stop)
            elif action == 'paper_stop':
                await self.exit(strategy,identity)

    async def report_daily(self, day, now):
        from .etf_csv_sync import completed_session
        identity = 'daily:'+day
        if self.journal.db.execute('SELECT 1 FROM notifications WHERE id=?',(identity,)).fetchone():
            return
        if not completed_session('XKRX',day,now,5):
            return
        data = await self.account_report(day)
        self.journal.notify(identity, 'mock_daily', data)

    async def account_report(self, day):
        """Store a current valuation for read-only Telegram queries."""
        closed = self.journal.db.execute("SELECT payload,created_ns FROM notifications WHERE id=? AND kind='mock_daily'", ('daily:'+day,)).fetchone()
        if closed:
            return await self.persist_account_report(day, json.loads(closed['payload']), closed['created_ns'])
        states={scope:await broker.account_state() for scope,broker in getattr(self,'brokers',{'mock':self.broker}).items()}
        end=start=Decimal(0); fees=Decimal(0); fees_available=True; positions={}; accounts={}
        for scope,state in states.items():
            summary=state['summary']; final=Decimal(str(summary['tot_evlu_amt'])); initial=Decimal(str(summary['bfdy_tot_asst_evlu_amt']))
            if not final.is_finite() or not initial.is_finite() or initial<=0: raise RuntimeError('Previous-day mock equity is unavailable')
            end+=final; start+=initial
            cost=summary.get('thdt_tlex_amt'); fees_available &= cost not in (None,'')
            fees+=Decimal(str(cost or 0))
            accounts[scope]={'net_pnl':str(final-initial),'equity':str(final),'fees':cost}
            positions.update({scope+':'+r['pdno']:r['hldg_qty'] for r in state['positions'] if Decimal(str(r['hldg_qty']))>0})
        marks={s:rows[max(rows)]['close'] for s,rows in self.today.items() if rows} if hasattr(self,'today') else {}
        opening={}
        if hasattr(self,'history'):
            for symbol,frame in self.history.daily.items():
                prior=frame[frame.date<day]
                if len(prior): opening[symbol]=prior.iloc[-1]['close']
        for symbol in self.journal.assumed_positions():
            result=await self.broker_for(symbol).client.get('/uapi/domestic-stock/v1/quotations/inquire-price',
                tr_id='FHKST01010100',params={'FID_COND_MRKT_DIV_CODE':'J','FID_INPUT_ISCD':symbol})
            marks[symbol]=Decimal(str(result['body']['output']['stck_prpr']))
            if marks[symbol]<=0: raise RuntimeError('Invalid close price for assumed position')
            await asyncio.sleep(.6)
        assumed=self.journal.assumed_report(day,marks,opening)
        data = {'day':day,'net_pnl':str(end-start),
            'equity':str(end),'fees':str(fees) if fees_available else None,'accounts':accounts,'assumed':assumed,
            'adjusted_net_pnl':str(end-start+Decimal(assumed['net_pnl'])),
            'adjusted_fees':str(fees+Decimal(assumed['fees'])) if fees_available else None,
            'fee_basis':'KIS 당일 제비용','pending_orders':len(self.journal.pending()),
            'positions':positions,'validation':self.validation_summary(day)}
        return await self.persist_account_report(day, data)

    async def persist_account_report(self, day, data, asof_ns=None):
        broker_fills = []
        brokers = getattr(self, 'brokers', {'mock':self.broker})
        if all(hasattr(broker, 'daily_fills') for broker in brokers.values()):
            for scope, broker in brokers.items():
                broker_fills.extend((scope, day, row['order_number'], row['symbol'], row['side'], row['quantity'], row['notional'])
                    for row in await broker.daily_fills(day))
            with self.journal.transaction():
                self.journal.db.execute('DELETE FROM broker_trades WHERE day=?', (day,))
                self.journal.db.executemany('INSERT OR REPLACE INTO broker_trades VALUES(?,?,?,?,?,?,?)', broker_fills)
                data['broker_fills_complete'] = True
        self.journal.db.execute('INSERT OR REPLACE INTO account_reports VALUES(?,?,?)',
            (day,json.dumps(data,default=str),asof_ns or time.time_ns()))
        return data

    async def refresh_account_report(self, day):
        try:
            await self.account_report(day)
        except Exception as exc:
            log.warning('Trade valuation refresh deferred (%s)', type(exc).__name__)

    def validation_summary(self,day):
        if not hasattr(self,'settings'): return None
        path=self.settings.state_dir/'etf-mock/mock2-validation.json'
        if not path.exists(): return None
        data=json.loads(path.read_text())
        if not data.get('complete') or datetime.fromtimestamp(data['created_ns']/1e9,KST).strftime('%Y-%m-%d')!=day: return None
        gross=sum((Decimal(str(row.get('notional') or 0))*(1 if row['side']=='sell' else -1) for row in data['orders']),Decimal(0))
        net=Decimal(data['validation_net_pnl'])
        return {'net_pnl':str(net),'fees':str(gross-net),'included_in_actual':True}

    async def timer(self):
        last_reconcile = 0.
        last_health = 0.
        last_daily_attempt = 0.
        last_report = 0.
        report_task = None
        while True:
            now = datetime.now(KST)
            day = now.strftime('%Y-%m-%d')
            if now.weekday()<5 and '09:00'<=now.strftime('%H:%M')<='15:35' and time.monotonic()-last_report>=60 and (report_task is None or report_task.done()):
                last_report = time.monotonic()
                report_task = asyncio.create_task(self.refresh_account_report(day))
            if day != self._day:
                self._day = day
                self.journal.roll_day(day)
                self.today = {s:{} for s in ETF_HISTORY_ROLES}
                self.phase = 'waiting_session'
            if now.weekday() < 5 and '08:40' <= now.strftime('%H:%M') <= '15:30' and self.history.day != day:
                if self._warmup_task is None or self._warmup_task.done():
                    self._warmup_task = asyncio.create_task(self.prepare(day))
            async with self._lock:
                pending = self.journal.pending()
                due = any(r['order_type']=='limit' and r['status']=='pending' and time.time_ns()-(r['accepted_ns'] or r['created_ns'])>=5_000_000_000 and not r['cancel_requested'] for r in pending)
                if (pending and (due or time.monotonic()-last_reconcile >= 1)) or self.journal.fallback_candidates():
                    try:
                        await self.reconcile()
                    except Exception:
                        log.exception('ETF reconciliation/replacement deferred')
                    last_reconcile = time.monotonic()
                clock = now.strftime('%H:%M:%S')
                for strategy in ('C3','KP','KD'):
                    deadline = '15:19:55' if strategy != 'C3' else '15:20:05'
                    # Submit while continuous quotes are still tradable. KRX's
                    # closing auction cannot be reconstructed as a past fill.
                    if clock >= deadline and clock <= '15:30:00':
                        try:
                            await self.exit(strategy,f'{strategy}:{day}:session_exit:{int(time.time())//30}',auction_market=strategy=='C3')
                        except Exception:
                            log.exception('ETF session liquidation waiting for valid quote/broker')
                    if clock >= '09:00:00' and clock < '09:05:00' and self.journal.book(strategy)['positions'] and self.journal.book(strategy)['day'] == day and self.journal.book(strategy)['entries'] == 0:
                        try:
                            await self.exit(strategy,f'{strategy}:{day}:overnight_recovery:{int(time.time())//30}')
                        except Exception:
                            log.exception('ETF overnight recovery waiting for quotes')
                if clock>='15:35:00' and now.weekday()<5 and time.monotonic()-last_daily_attempt>=60:
                    last_daily_attempt=time.monotonic()
                    try:
                        await self.report_daily(day,now)
                    except Exception:
                        log.exception('Mock daily report deferred pending broker response')
            if time.monotonic()-last_health >= 10:
                touch(self.settings,'etf-mock',detail={'phase':self.phase,'account_mode':'mock',
                    'account_routes':{'mock':['069500','229200'],'mock2':['122630','251340']},
                    'assumed_positions':self.journal.assumed_positions(),
                    'day':day,'books':{s:{k:str(v) if isinstance(v,Decimal) else v for k,v in b.items()} for s,b in self.journal.summary().items()},
                    'pending_orders':len(self.journal.pending()),'c3_inputs_ready':not self.history.index.empty,
                    'vehicle_bars':{s:{'completed_today':len(rows),
                        'latest_close':max(rows.values(),key=lambda r:r['timestamp'])['close'] if rows else None} for s,rows in self.today.items()}})
                last_health = time.monotonic()
            await asyncio.sleep(.1 if self.journal.pending() else 1)

    async def run(self):
        await self.initialize()
        client = await nats.connect(self.settings.nats.url)
        queue = asyncio.Queue(maxsize=10000)
        async def receive(msg):
            await queue.put(json.loads(msg.data))
        subscription = await client.subscribe('live.md.*.kiwoom.etf.>',cb=receive)
        timer = asyncio.create_task(self.timer())
        try:
            while True:
                if timer.done():
                    timer.result()
                try:
                    data = await asyncio.wait_for(queue.get(),timeout=1)
                except asyncio.TimeoutError:
                    continue
                try:
                    await self.event(data)
                except Exception:
                    log.exception('ETF event processing failed; submitted state retained')
        finally:
            timer.cancel()
            await asyncio.gather(timer,return_exceptions=True)
            await subscription.unsubscribe()
            await client.close()
            await self.bus.close()
            self.journal.db.close()


async def check(warmup: bool):
    loop = EtfTradingLoop()
    await loop.initialize()
    if warmup:
        await loop.history.prepare(datetime.now(KST).strftime('%Y-%m-%d'))
        etf = await loop.kiwoom.post_api('/api/dostk/stkinfo','ka10001',{'stk_cd':'069500'})
        index = await loop.kiwoom.post_api('/api/dostk/sect','ka20001',{'mrkt_tp':'0','inds_cd':'201'})
        c3_check = loop.history.c3(abs(float(etf['open_pric'])),abs(float(index['open_pric'])))
    else:
        c3_check = None
    market_power = await loop.broker.buying_power('069500',Decimal(0),market=True)
    if Decimal(str(market_power.get('psbl_qty_calc_unpr') or 0)) <= 0:
        raise RuntimeError('Market fallback reservation price is unavailable')
    result = {'mock':True,'books':loop.journal.summary(),'c3_ready':not loop.history.index.empty,'phase':loop.phase,
        'reference_usage':loop.history.reference_usage,'execution':'immediate_limit_then_5s_confirmed_remaining_market',
        'vehicle_history':{s:loop.history.vehicle_reference(s) for s in ETF_HISTORY_ROLES} if warmup else {},
        'market_reservation_price':market_power['psbl_qty_calc_unpr'],'native_open_signal_probe':c3_check}
    print(json.dumps(result,default=str))
    await loop.bus.close()
    loop.journal.db.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command',choices=['check','run'])
    parser.add_argument('--warmup',action='store_true')
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)
    asyncio.run(check(args.warmup) if args.command=='check' else EtfTradingLoop().run())


if __name__ == '__main__':
    main()
