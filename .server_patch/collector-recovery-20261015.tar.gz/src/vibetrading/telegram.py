from __future__ import annotations

import asyncio
import logging
import shutil
import time
import json
import sqlite3
from decimal import Decimal
from contextlib import closing
from dataclasses import replace
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

import aiohttp
import psutil

from .bus import NatsJetStreamBus
from .health import check as health_check
from .health import configured_crypto_providers
from .session_alerts import SESSIONS, session_state
from .settings import RuntimeSettings, get_settings
from .telegram_trade import trade_report
from .trade_reporting import daily_report_view

logger = logging.getLogger(__name__)


class TelegramController:
    """Minimal allowlisted control/observability loop; inactive without credentials."""

    def __init__(self, settings: RuntimeSettings | None = None) -> None:
        self.settings = settings or get_settings()
        self.token = self.settings.env.get("TELEGRAM_BOT_TOKEN")
        self.allowed_id = str(self.settings.telegram_user_id or "")
        self.base_url = f"https://api.telegram.org/bot{self.token}" if self.token else ""
        self._offset = 0
        self._sent_session: set[str] = set()
        self._crypto_alerted: set[str] = set()
        self._crypto_alert_at: dict[str, float] = {}
        self._market_alert_at: dict[str, float] = {}
        self._market_unready_since: dict[str, float] = {}

    @property
    def enabled(self) -> bool:
        return bool(self.token and self.allowed_id)

    async def run(self, poll_seconds: int = 25) -> None:
        if not self.enabled:
            logger.warning("Telegram controller disabled: TELEGRAM_BOT_TOKEN/TELEGRAM_USER_ID missing")
            return
        timeout = aiohttp.ClientTimeout(total=poll_seconds + 10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            bus = NatsJetStreamBus(self.settings)
            try:
                await asyncio.gather(
                    self._poll_loop(session, poll_seconds),
                    self._event_bridge_loop(session, bus),
                    self._crypto_health_loop(session),
                    self._market_health_loop(session),
                    self._mock_notifications_loop(session),
                )
            finally:
                await bus.close()

    async def _poll_loop(self, session: aiohttp.ClientSession, poll_seconds: int) -> None:
        failures=0
        while True:
            try:
                response = await self._api(session, "getUpdates", {"timeout": poll_seconds, "offset": self._offset})
            except (asyncio.TimeoutError,aiohttp.ClientConnectionError) as exc:
                failures+=1
                logger.warning('Telegram polling will retry (%s)',type(exc).__name__)
                await asyncio.sleep(min(30,2**min(failures,5)))
                continue
            except aiohttp.ClientResponseError as exc:
                if exc.status!=429 and exc.status<500: raise
                failures+=1
                logger.warning('Telegram polling will retry status=%s',exc.status)
                await asyncio.sleep(min(30,2**min(failures,5)))
                continue
            failures=0
            for update in response.get("result", []):
                # A reply failure must not acknowledge and lose the command.
                while True:
                    try:
                        await self._handle(session, update)
                        break
                    except (asyncio.TimeoutError, aiohttp.ClientError) as exc:
                        failures += 1
                        logger.warning('Telegram reply deferred (%s)', type(exc).__name__)
                        await asyncio.sleep(min(30, 2**min(failures, 5)))
                self._offset = max(self._offset, int(update.get("update_id", 0)) + 1)

    async def _event_bridge_loop(self, session, bus):
        while True:
            try:
                await bus.connect(initialize=False)
                await self._event_bridge(session, bus)
            except Exception as exc:
                logger.warning('Telegram event bridge reconnecting (%s)', type(exc).__name__)
            finally:
                await bus.close()
            await asyncio.sleep(10)

    async def _event_bridge(self, session: aiohttp.ClientSession, bus: NatsJetStreamBus) -> None:
        # Never consume the high-volume market-data subjects here.  A single
        # catch-all consumer can get buried behind ticks and then discard
        # collector lifecycle events as "old" before Telegram sees them.
        # Operational subjects have independent durable cursors so a market
        # burst cannot delay alerts or order/signal notifications.
        subjects = ("system.>", "signal.>", "order.>", "md.data_gap.>")
        await asyncio.gather(*(
            self._event_bridge_subject(session, bus, subject, f"telegram-event-bridge-{index}")
            for index, subject in enumerate(subjects)
        ))

    async def _event_bridge_subject(self, session: aiohttp.ClientSession, bus: NatsJetStreamBus, subject: str, durable: str) -> None:
        async for message in bus.subscribe(subject, durable=durable, batch=100):
            data = message.data
            provider = str(data.get('provider') or '')
            if provider.endswith('-perp') and provider not in configured_crypto_providers(self.settings):
                await message.ack()
                continue
            # A durable bridge may be recreated after a long outage.  Do not
            # replay historical market ticks into Telegram; storage consumers
            # retain the complete history in Parquet.
            kind = str(data.get("kind") or data.get("event_type") or "")
            if message.subject.startswith("md.trade.") or message.subject.startswith("md.order_book.") or message.subject.startswith("md.index_quote."):
                # Market data is stored in Parquet, not pushed to Telegram.
                await message.ack()
                continue
            elif message.subject.startswith("md.data_gap"):
                kind = "gap"
            elif message.subject.startswith("signal."):
                kind = "signal"
            elif message.subject.startswith("order."):
                destination = str(data.get("destination", "")).lower()
                # Timefolio intents are operationally important even before
                # submission; real-account notifications exclude blocked and
                # pre-submit records.
                if destination == "timefolio":
                    kind = "timefolio_intent"
                elif destination == "real" and str(data.get("status", "")).lower() not in {"created", "blocked"}:
                    kind = "execution"
                else:
                    await message.ack()
                    continue
            elif message.subject.startswith("system."):
                kind = str(data.get("kind") or "system")
                if kind == 'collector_start':
                    self._crypto_alerted.discard(provider)
                    self._crypto_alert_at.pop(provider, None)
                if kind not in {"collector_error", "storage_error", "compactor_error"}:
                    await message.ack()
                    continue
            else:
                await message.ack(); continue
            # Operational events must not be dropped merely because the
            # market-data bridge was behind. They are isolated now, so a
            # bounded replay window safely prevents stale deployment-era
            # errors from being delivered as current incidents.
            ts_ns = int(data.get("created_ts_ns") or data.get("event_ts_ns") or data.get("ts_ns") or 0)
            try:
                max_age_seconds = max(60, int(self.settings.env.get("TELEGRAM_EVENT_MAX_AGE_SECONDS", "300")))
            except ValueError:
                max_age_seconds = 300
            if ts_ns and time.time_ns() - ts_ns > max_age_seconds * 1_000_000_000:
                await message.ack()
                continue
            try:
                provider = str(data.get("provider") or "")
                if kind == "collector_error" and provider in configured_crypto_providers(self.settings):
                    await self._crypto_issue(session, provider, str(data.get("error") or "수집 오류"))
                elif kind == 'collector_error' and provider in {'kis','kiwoom','toss'}:
                    await self._market_issue(session, provider, str(data.get('error') or data.get('reason') or '수집 오류'))
                elif kind == "collector_start" and provider in configured_crypto_providers(self.settings):
                    await self._crypto_recovered(session, provider)
                else:
                    await self._send(session, self.allowed_id, self._format_event(kind, data))
            except aiohttp.ClientResponseError as exc:
                # Telegram allows only a small outbound rate.  A throttled
                # notification is intentionally dropped; the market event is
                # already durable in NATS/Parquet and should not block acks.
                if exc.status != 429:
                    logger.warning("Telegram event push failed subject=%s status=%s", message.subject, exc.status)
            except Exception:
                logger.exception("Telegram event push failed subject=%s", message.subject)
            await message.ack()

    async def _crypto_issue(self, session: aiohttp.ClientSession, provider: str, reason: str) -> None:
        if provider not in configured_crypto_providers(self.settings):
            return
        now = time.monotonic()
        if now - self._crypto_alert_at.get(provider, -1e9) < 300:
            return
        name = provider.split("-", 1)[0].title()
        await self._send(session, self.allowed_id, f"🚨 {name} 선물 수집 오류\n{reason[:180]}\n재연결 상태는 status로 확인")
        self._crypto_alerted.add(provider)
        self._crypto_alert_at[provider] = now

    async def _crypto_recovered(self, session: aiohttp.ClientSession, provider: str) -> None:
        if provider not in configured_crypto_providers(self.settings):
            self._crypto_alerted.discard(provider)
            self._crypto_alert_at.pop(provider,None)
            return
        self._crypto_alerted.discard(provider)
        self._crypto_alert_at.pop(provider, None)

    async def _crypto_health_loop(self, session: aiohttp.ClientSession) -> None:
        while True:
            try:
                group = health_check(self.settings, "crypto-collectors", 90)
                # An absent heartbeat means the optional crypto profile is off.
                if group.get("reason") != "heartbeat_missing":
                    for provider in configured_crypto_providers(self.settings):
                        if provider not in group.get("providers", []):
                            continue
                        worker = health_check(self.settings, f"collectors-{provider}", 90)
                        if float(group.get("age_seconds") or 0) > 90:
                            await self._crypto_issue(session, provider, "코인 수집기 응답 없음")
                        elif worker.get("state") == "error" or worker.get("phase") == "paused":
                            await self._crypto_issue(session, provider, str(worker.get("reason") or "수집 중단"))
                        elif float(worker.get("age_seconds") or 0) > 90:
                            await self._crypto_issue(session, provider, "수집 상태 갱신 중단")
                        elif worker.get("phase") == "publishing" and float(worker.get("event_age_seconds") or 0) <= 90:
                            await self._crypto_recovered(session, provider)
            except Exception:
                logger.exception("Telegram crypto health alert check failed")
            await asyncio.sleep(30)

    async def _market_issue(self, session, provider: str, reason: str) -> None:
        now = time.monotonic()
        if now-self._market_alert_at.get(provider, -1e9)<300:
            return
        await self._send(session, self.allowed_id, f'[COLLECTOR ERROR] provider={provider} reason={reason[:350]}')
        self._market_alert_at[provider] = now
        logger.info('Telegram collector alert delivered provider=%s', provider)

    @staticmethod
    def _expected_market_collectors() -> dict[str, bool]:
        equity = session_state('KR_EQUITY_ETF')[0]
        return {'kis':equity or session_state('KR_DERIVATIVES')[0], 'kiwoom':equity,
                'toss':equity or session_state('US_EQUITY_ETF')[0]}

    async def _market_health_once(self, session, expected: dict[str, bool]) -> None:
        now_ns, monotonic = time.time_ns(), time.monotonic()
        for provider, active in expected.items():
            if not active:
                self._market_unready_since.pop(provider, None)
                self._market_alert_at.pop(provider, None)
                continue
            worker = health_check(self.settings, 'collectors-'+provider, 120)
            age = float(worker.get('age_seconds') or 0)
            phase = worker.get('phase')
            reason = None
            if worker.get('reason') == 'heartbeat_missing' or age>120:
                reason = '장중 수집기 heartbeat 없음/갱신 중단'
            elif worker.get('state') == 'error' or phase in {'paused','retrying','error'}:
                reason = str(worker.get('reason') or '장중 수집 오류')
            else:
                seen = max([int(v) for v in (worker.get('symbol_last_seen_ns') or {}).values()] or [0])
                last = seen or int(worker.get('last_event_ts_ns') or 0)
                if last and now_ns-last>180_000_000_000:
                    reason = f'장중 실제 데이터 수신 중단 ({int((now_ns-last)/1e9)}초)'
                elif phase != 'publishing' or not last:
                    since = self._market_unready_since.setdefault(provider, monotonic)
                    if monotonic-since>=120:
                        reason = '개장 후 수집 미시작/실제 데이터 수신 없음'
                else:
                    self._market_unready_since.pop(provider, None)
                    self._market_alert_at.pop(provider, None)
            if reason:
                guard_path = self.settings.state_dir/'health'/'os-disk-guard.json'
                try:
                    guard = json.loads(guard_path.read_text(encoding='utf-8'))
                    if guard.get('paused'):
                        reason += f"; OS 디스크 보호 중지, 여유 {int(guard.get('free_bytes',0))/1024**3:.2f}GiB"
                except (OSError, ValueError, TypeError):
                    pass
                await self._market_issue(session, provider, reason)

    async def _market_health_loop(self, session) -> None:
        # Independent of both the producer process and the NATS event bridge:
        # a stopped process cannot publish its own collector_error event.
        while True:
            try:
                expected = await asyncio.to_thread(self._expected_market_collectors)
                await self._market_health_once(session, expected)
            except Exception:
                logger.exception('Telegram market collector health check failed')
            await asyncio.sleep(30)

    def _compact_status(self) -> str:
        now = datetime.now(ZoneInfo("Asia/Seoul")).strftime("%m/%d %H:%M")
        workers = {name: health_check(self.settings, name, 120 if name != "maintenance" else 420)
                   for name in ("collectors", "storage", "maintenance")}
        healthy = sum(bool(item.get("ok")) for item in workers.values())
        memory = psutil.virtual_memory()
        used_gib = (memory.total - memory.available) / 1024**3
        available_gib = memory.available / 1024**3
        disk = shutil.disk_usage(self.settings.data_root)
        crypto = health_check(self.settings, "crypto-collectors", 90)
        crypto_expected = crypto.get("reason") != "heartbeat_missing"
        profile_running = crypto_expected and float(crypto.get("age_seconds", 1e9)) <= 90
        if crypto_expected:
            crypto_settings = replace(self.settings, state_dir=self.settings.data_root / "crypto_state")
            crypto_storage = health_check(crypto_settings, "crypto-storage", 120)
            crypto_archive = health_check(crypto_settings, "maintenance", 420)
            crypto_services_ok = bool(crypto_storage.get("ok") and crypto_archive.get("ok"))
            crypto_service_line = (f"코인 저장 {'정상' if crypto_storage.get('ok') else '오류'}"
                                   f" · 보관 {'정상' if crypto_archive.get('ok') else '오류'}")
        else:
            crypto_services_ok = True
            crypto_service_line = "코인 저장·보관: 중지"
        venue_lines: list[str] = []
        live_symbols: set[str] = set()
        all_venues_collecting = True
        for provider in configured_crypto_providers(self.settings):
            venue = provider.split('-',1)[0].title()
            # One stale venue must not hide the other venues' live symbols.
            worker = health_check(self.settings, f"collectors-{provider}", 90)
            if worker.get('reason') == 'heartbeat_missing':
                label = "중지"
            elif float(worker.get('age_seconds', 1e9)) > 90:
                label = '응답 없음'
            elif worker.get('phase') == 'paused':
                label = '일시 중지'
            elif not worker.get("ok"):
                label = "오류" if worker.get("state") == "error" else "응답 없음"
            elif worker.get("phase") != "publishing":
                label = "연결 중"
            elif float(worker.get("event_age_seconds") or 0) > 90:
                label = "데이터 지연"
            else:
                seen = worker.get("symbol_last_seen_ns") or {}
                symbols = sorted(symbol for symbol, ts in seen.items()
                                 if symbol in {"BTCUSDT", "ETHUSDT", "SOLUSDT"}
                                 and time.time_ns() - int(ts) <= 120 * 1_000_000_000)
                live_symbols.update(symbols)
                label = ", ".join(symbols) if symbols else "연결됨 · 종목 확인 중"
            if label != "BTCUSDT, ETHUSDT, SOLUSDT":
                all_venues_collecting = False
            venue_lines.append(f"{venue}: {label}")
        overall = "정상" if healthy == 3 and available_gib >= 0.5 and crypto_services_ok and (not crypto_expected or (profile_running and all_venues_collecting)) else "주의"
        domestic_lines=[]
        from .universe_config import configured_symbols
        for provider,label in [('kis','KIS'),('kiwoom','Kiwoom'),('toss','TOSS')]:
            worker=health_check(self.settings,'collectors-'+provider,120)
            phase=worker.get('phase','')
            fresh=sorted(s for s,ts in (worker.get('symbol_last_seen_ns') or {}).items()
                if time.time_ns()-int(ts)<=120_000_000_000)
            if phase=='market_closed' and worker.get('ok'): state='장 종료'
            elif not worker.get('ok'): state='오류/응답 없음'
            elif phase=='paused': state='일시 중지'
            elif fresh: state='수집 정상'
            elif phase in {'connecting','recovering'}: state='연결/복구 중'
            else: state='최근 수신 없음'
            if state not in {'수집 정상','장 종료'}: overall='주의'
            configured=', '.join(configured_symbols(provider)) or ('근월·차근월 선물' if provider=='kis' else '없음')
            domestic_lines.append(f'{label}: {state}\n  최근 수신: {", ".join(fresh) or "없음"}\n  설정: {configured}')
        return "\n".join((
            f"📊 서버 {overall} · {now} KST",
            f"서비스 {healthy}/3 정상 · 메모리 {used_gib:.1f}/{memory.total / 1024**3:.1f} GiB (가용 {available_gib:.1f})",
            f"저장공간 {(disk.total - disk.free) / 1024**3:.1f}/{disk.total / 1024**3:.1f} GiB",
            crypto_service_line,
            '국내·미국 수집기 (최근 120초 실제 수신):',
            *domestic_lines,
            "코인 무기한 선물:",
            *venue_lines,
            f"실제 수집 종목: {', '.join(sorted(live_symbols)) if live_symbols else '없음'}",
        ))

    def _pending_mock_notifications(self):
        path=self.settings.state_dir/'etf-mock'/'journal.sqlite3'
        if not path.exists(): return []
        with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True,timeout=.5)) as db:
            if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='notifications'").fetchone(): return []
            return [{'id':r[0],'kind':r[1],'payload':json.loads(r[2])} for r in
                db.execute('SELECT id,kind,payload FROM notifications WHERE sent_ns IS NULL ORDER BY created_ns LIMIT 50')]

    def _mark_mock_notification(self, identity):
        with sqlite3.connect(self.settings.state_dir/'etf-mock'/'journal.sqlite3',timeout=.5) as db:
            db.execute('UPDATE notifications SET sent_ns=? WHERE id=? AND sent_ns IS NULL',(time.time_ns(),identity))

    @staticmethod
    def _format_mock_notification(kind, data):
        side='매수' if data.get('side')=='buy' else '매도'
        if kind=='mock_order':
            price='시장가' if data['order_type']=='market' else f"지정가 {Decimal(data['price']):,.0f}원"
            return f"[KIS 모의 주문 접수 · {data.get('account_scope','mock')}]\n{data['strategy']} · {data['symbol']} {side} {data['quantity']}주\n{price}\n주문번호 {data['order_number']}"
        if kind=='mock_fill':
            state='전량 체결' if data['complete'] else '부분 체결'
            return f"[KIS 모의 {state} · {data.get('account_scope','mock')}]\n{data['strategy']} · {data['symbol']} {side} {data['filled_quantity']}주\n체결가 {Decimal(data['fill_price']):,.2f}원\n누적 {data['total_filled']}/{data['ordered_quantity']}주 · 주문번호 {data['order_number']}"
        if kind=='mock_assumed':
            stamp=datetime.fromtimestamp(data['event_ns']/1e9,ZoneInfo('Asia/Seoul')).strftime('%m/%d %H:%M:%S') if data.get('event_ns') else ''
            return f"[전략 평가용 가정 체결 · 실제 체결 아님]\n{data['strategy']} · {data['symbol']} {side} {data['quantity']}주\n가정 시각 {stamp} KST · Best quote {Decimal(data['price']):,.0f}원\n{data['reason']}"
        if kind=='mock_rejected':
            return f"[KIS 모의 주문 거절]\n{data['strategy']} · {data['symbol']} {side} {data['quantity']}주\n{data['reason']}"
        if kind=='mock_daily':
            fees='조회 불가' if data.get('fees') is None else f"{Decimal(data['fees']):,.0f}원"
            positions=', '.join(f'{s} {q}주' for s,q in data['positions'].items()) or '없음'
            text=f"[KIS 모의 장 마감 보고 · {data['day']}]\n실제 계좌 순수익 {Decimal(data['net_pnl']):+,.0f}원\n수수료·제비용(KIS) {fees}\n계좌 평가액 {Decimal(data['equity']):,.0f}원\n미체결 {data['pending_orders']}건 · 보유 {positions}\n순수익 기준: 전일 대비 계좌 평가액 증감(보유 시 평가손익 포함)"
            for scope,account in data.get('accounts',{}).items():
                text+=f"\n{scope} 순수익 {Decimal(account['net_pnl']):+,.0f}원"
            assumed=data.get('assumed')
            if assumed:
                text+=f"\n권한 거절 가정 순수익 {Decimal(assumed['net_pnl']):+,.0f}원 ({assumed['fill_count']}건)\n가정 수수료(추정) {Decimal(assumed['fees']):,.2f}원\n보정 순수익(실제+가정) {Decimal(data['adjusted_net_pnl']):+,.0f}원"
                if data.get('adjusted_fees') is not None: text+=f"\n합산 수수료·제비용 {Decimal(data['adjusted_fees']):,.2f}원"
            if data.get('validation'):
                text+=f"\n실제 합계에 포함된 1주 검증 손익 {Decimal(data['validation']['net_pnl']):+,.0f}원 · 수수료 {Decimal(data['validation']['fees']):,.0f}원"
            if data.get('test_trades_excluded'):
                text+='\n사용자 지정 테스트 거래의 손익·수수료 제외'
            return text
        raise ValueError('Unknown mock notification kind')

    async def _deliver_mock_notifications(self, session):
        for row in await asyncio.to_thread(self._pending_mock_notifications):
            data = await asyncio.to_thread(daily_report_view,self.settings,row['payload']) if row['kind']=='mock_daily' else row['payload']
            await self._send(session,self.allowed_id,self._format_mock_notification(row['kind'],data))
            await asyncio.to_thread(self._mark_mock_notification,row['id'])

    async def _mock_notifications_loop(self, session):
        while True:
            try: await self._deliver_mock_notifications(session)
            except Exception as exc:
                logger.warning('Mock account notifications deferred; unsent records retained (%s)',type(exc).__name__)
            await asyncio.sleep(1)

    async def _session_loop(self, session: aiohttp.ClientSession) -> None:
        # Market open/close is normal operation and never pushes a notice.
        while True:
            await asyncio.sleep(20)

    @staticmethod
    def _format_event(kind: str, data: dict[str, Any]) -> str:
        if kind == "gap":
            return f"[DATA GAP] provider={data.get('provider')} instrument={data.get('instrument', {}).get('std_symbol', '?')} reason={data.get('reason', '')} seq={data.get('missing_from_sequence')}..{data.get('missing_to_sequence')}"
        if kind == "signal":
            text = f"[SIGNAL · 체결 아님] {data.get('strategy_id')} {data.get('action')}\n기준 종목: {data.get('instrument', {}).get('std_symbol', '?')}"
            weights = data.get('metadata',{}).get('weights',{})
            targets = ', '.join(f'{symbol} ({Decimal(str(weight))*100:g}%)' for symbol,weight in weights.items() if Decimal(str(weight))>0)
            return text + (f'\n주문 대상: {targets}' if targets else '') + '\n주문 접수·체결 여부는 별도 알림과 trade에서 확인'
        if kind == "timefolio_intent":
            return f"[TIMEFOLIO INTENT] job={data.get('job_id')} {data.get('side')} {data.get('instrument', {}).get('std_symbol', '?')} status={data.get('status')}"
        if kind == "execution":
            return f"[REAL ORDER] job={data.get('job_id')} {data.get('side')} {data.get('instrument', {}).get('std_symbol', '?')} status={data.get('status')} client={data.get('client_order_id')}"
        if kind == "collector_start":
            return f"[COLLECTOR START] provider={data.get('provider')} symbols={data.get('symbols') or 'auto'}"
        if kind == "collector_stop":
            suffix = f" reason={data.get('reason')}" if data.get("reason") else ""
            return f"[COLLECTOR STOP] provider={data.get('provider')} symbols={data.get('symbols') or 'auto'}{suffix}"
        reason = data.get("error") or data.get("message") or data.get("kind", "")
        cause = f" cause={data.get('cause')}" if data.get("cause") else ""
        failures = data.get("consecutive_failures")
        outage = data.get("outage_seconds")
        state = f" failures={failures} outage={outage}s" if failures is not None else ""
        return f"[COLLECTOR ERROR] provider={data.get('provider', '')} reason={reason}{cause}{state}"

    async def _handle(self, session: aiohttp.ClientSession, update: dict[str, Any]) -> None:
        message = update.get("message") or {}
        sender = str((message.get("from") or {}).get("id", ""))
        if sender != self.allowed_id:
            return
        text = str(message.get("text") or "").strip().lower()
        command = text.split(maxsplit=1)[0].split('@', 1)[0].lstrip('/') if text else ''
        chat_id = message.get("chat", {}).get("id")
        if command == 'status':
            try:
                reply = await asyncio.to_thread(self._compact_status)
            except Exception as exc:
                logger.warning('Collector status unavailable (%s)', type(exc).__name__)
                reply = '수집기 상태 조회 실패. 서버 상태 파일을 확인해야 합니다.'
            await self._send(session, chat_id, reply)
            logger.info('Telegram command replied command=status')
        elif command == 'trade':
            try:
                reply = await asyncio.to_thread(trade_report, self.settings)
            except Exception as exc:
                logger.warning('Trade report unavailable (%s)', type(exc).__name__)
                reply = '거래 내역 조회 실패. 거래 기록을 확인해야 합니다.'
            await self._send(session, chat_id, reply)
            logger.info('Telegram command replied command=trade')
        elif command in {'help', 'start'}:
            await self._send(session, chat_id, 'status: 수집기별 상태·수집 종목\ntrade: 당일 종목별 거래·당일 및 전체 기록기간 순수익·수수료')

    async def _send(self, session: aiohttp.ClientSession, chat_id: Any, text: str) -> None:
        # Split at line boundaries so trade rows and summary lines are retained.
        parts = []
        for line in text.splitlines():
            while len(line) > 3900:
                parts.append(line[:3900]); line = line[3900:]
            if parts and len(parts[-1]) + len(line) + 1 <= 3900:
                parts[-1] += '\n' + line
            else:
                parts.append(line)
        for part in parts:
            await self._api(session, "sendMessage", {"chat_id": chat_id, "text": part})

    async def _api(self, session: aiohttp.ClientSession, method: str, params: dict[str, Any]) -> dict[str, Any]:
        async with session.get(f"{self.base_url}/{method}", params=params) as response:
            response.raise_for_status()
            payload = await response.json()
            if not payload.get("ok"):
                raise RuntimeError(f"Telegram API failed: {payload}")
            return payload
