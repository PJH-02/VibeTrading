"""Offline, fail-closed migration of the crypto delivery ledger.

Collectors and crypto storage must be stopped and CRYPTO_DATA must be empty.
The script preserves the original database beside the replacement.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import time
from pathlib import Path


COMPACT_DDL="""
CREATE TABLE IF NOT EXISTS delivery_stream (
  stream_id INTEGER PRIMARY KEY, stream_name TEXT NOT NULL, stream_generation TEXT NOT NULL,
  ack_floor INTEGER NOT NULL DEFAULT 0, updated_ts_ns INTEGER NOT NULL,
  UNIQUE(stream_name,stream_generation));
CREATE TABLE IF NOT EXISTS parquet_delivery_compact (
  stream_id INTEGER NOT NULL, stream_sequence INTEGER NOT NULL,
  event_key BLOB NOT NULL, file_rowid INTEGER NOT NULL, persisted_ts_ns INTEGER NOT NULL,
  PRIMARY KEY(stream_id,stream_sequence));
CREATE INDEX IF NOT EXISTS idx_delivery_compact_event ON parquet_delivery_compact(event_key);
CREATE INDEX IF NOT EXISTS idx_delivery_compact_prune ON parquet_delivery_compact(persisted_ts_ns,stream_id,stream_sequence);
"""


def event_key(value:str|None)->bytes:
    return hashlib.sha256(str(value or "").encode("utf-8")).digest()


def scalar(db:sqlite3.Connection,sql:str,parameters:tuple=())->int:
    return int(db.execute(sql,parameters).fetchone()[0])


def inspect(database:Path,retain_hours:int)->dict:
    db=sqlite3.connect(f"file:{database.as_posix()}?mode=ro",uri=True)
    try:
        cutoff=time.time_ns()-retain_hours*3600*1_000_000_000
        total=scalar(db,"SELECT COUNT(*) FROM parquet_delivery")
        missing=scalar(db,"SELECT COUNT(*) FROM parquet_delivery AS d LEFT JOIN parquet_manifest AS m ON m.file_id=d.file_id WHERE m.rowid IS NULL")
        eligible=scalar(db,"""SELECT COUNT(*) FROM parquet_delivery AS d JOIN parquet_manifest AS m ON m.file_id=d.file_id
                              WHERE d.persisted_ts_ns<=? AND m.upload_status='remote_verified' AND m.remote_manifest_key IS NOT NULL""",(cutoff,))
        backup=db.execute("SELECT remote_key,sha256,created_ts_ns FROM archive_backup ORDER BY created_ts_ns DESC LIMIT 1").fetchone()
        return {"database":str(database),"bytes":database.stat().st_size,"delivery_rows":total,
                "prune_eligible":eligible,"missing_manifest":missing,
                "last_remote_backup":{"key":backup[0],"sha256":backup[1],"created_ts_ns":int(backup[2])} if backup else None}
    finally:db.close()


def migrate(database:Path,retain_hours:int,min_free_gb:float,*,stream_drained:bool=True,
            current_generation:str|None=None,acked_through:int|None=None)->dict:
    report=inspect(database,retain_hours)
    if report["missing_manifest"]:raise RuntimeError("delivery rows without a manifest; refusing migration")
    if not report["last_remote_backup"]:raise RuntimeError("no recorded remote SQLite backup; refusing migration")
    free=shutil.disk_usage(database.parent).free
    minimum=int(min_free_gb*1024**3)
    if free<minimum:raise RuntimeError(f"requires at least {minimum} free bytes; found {free}")
    stamp=time.strftime("%Y%m%dT%H%M%SZ",time.gmtime())
    work=database.with_name(f".{database.name}.{stamp}.work")
    compact=database.with_name(f".{database.name}.{stamp}.compact")
    preserved=database.with_name(f"{database.name}.precompact-{stamp}")
    for path in (work,compact):
        if path.exists():raise RuntimeError(f"temporary path already exists: {path}")
    source=sqlite3.connect(database,isolation_level=None,timeout=120)
    try:
        busy=source.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()[0]
        if busy:raise RuntimeError("SQLite WAL is busy; storage or maintenance is still connected")
        target=sqlite3.connect(work,isolation_level=None)
        try:source.backup(target)
        finally:target.close()
    finally:source.close()
    db=sqlite3.connect(work,isolation_level=None,timeout=120)
    db.create_function("event_key",1,event_key,deterministic=True)
    try:
        db.execute("PRAGMA journal_mode=WAL");db.execute("PRAGMA synchronous=FULL");db.executescript(COMPACT_DDL)
        now=time.time_ns();cutoff=now-retain_hours*3600*1_000_000_000
        db.execute("BEGIN IMMEDIATE")
        if stream_drained:
            db.execute("""INSERT INTO delivery_stream(stream_name,stream_generation,ack_floor,updated_ts_ns)
                          SELECT stream_name,stream_generation,MAX(stream_sequence),?
                          FROM parquet_delivery GROUP BY stream_name,stream_generation""",(now,))
        else:
            if not current_generation or acked_through is None:raise RuntimeError("active stream migration requires generation and ACK floor")
            db.execute("""INSERT INTO delivery_stream(stream_name,stream_generation,ack_floor,updated_ts_ns)
                          SELECT stream_name,stream_generation,
                                 CASE WHEN stream_generation=? THEN MIN(MAX(stream_sequence),?) ELSE MAX(stream_sequence) END,?
                          FROM parquet_delivery GROUP BY stream_name,stream_generation""",
                       (current_generation,int(acked_through),now))
        db.execute("""INSERT INTO parquet_delivery_compact(stream_id,stream_sequence,event_key,file_rowid,persisted_ts_ns)
                      SELECT stream.stream_id,delivery.stream_sequence,event_key(delivery.event_id),manifest.rowid,delivery.persisted_ts_ns
                      FROM parquet_delivery AS delivery
                      JOIN delivery_stream AS stream ON stream.stream_name=delivery.stream_name AND stream.stream_generation=delivery.stream_generation
                      JOIN parquet_manifest AS manifest ON manifest.file_id=delivery.file_id
                      WHERE NOT (delivery.persisted_ts_ns<=? AND delivery.stream_sequence<=stream.ack_floor
                                 AND manifest.upload_status='remote_verified' AND manifest.remote_manifest_key IS NOT NULL)""",(cutoff,))
        compact_rows=scalar(db,"SELECT COUNT(*) FROM parquet_delivery_compact")
        pruned_rows=int(report["delivery_rows"])-compact_rows
        if compact_rows+pruned_rows!=int(report["delivery_rows"]):
            raise RuntimeError("migration row counts do not reconcile")
        db.execute("DELETE FROM parquet_delivery")
        db.execute("COMMIT")
        if db.execute("PRAGMA integrity_check").fetchone()[0]!="ok":raise RuntimeError("working database integrity check failed")
        db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        db.execute("VACUUM INTO ?",(str(compact),))
    except Exception:
        if db.in_transaction:db.execute("ROLLBACK")
        raise
    finally:db.close()
    check=sqlite3.connect(f"file:{compact.as_posix()}?mode=ro",uri=True)
    try:
        if check.execute("PRAGMA integrity_check").fetchone()[0]!="ok":raise RuntimeError("compact database integrity check failed")
        final_rows=scalar(check,"SELECT COUNT(*) FROM parquet_delivery_compact")
    finally:check.close()
    os.replace(database,preserved)
    for suffix in ("-wal","-shm"):
        sidecar=Path(str(database)+suffix)
        if sidecar.exists():os.replace(sidecar,Path(str(preserved)+suffix))
    os.replace(compact,database)
    work.unlink(missing_ok=True)
    for suffix in ("-wal","-shm"):
        sidecar=Path(str(work)+suffix)
        sidecar.unlink(missing_ok=True)
    return {**report,"status":"migrated","compact_rows":final_rows,"pruned_rows":pruned_rows,"new_bytes":database.stat().st_size,
            "preserved_database":str(preserved)}


def main()->None:
    parser=argparse.ArgumentParser()
    parser.add_argument("--database",type=Path,required=True)
    parser.add_argument("--retain-hours",type=int,default=24)
    parser.add_argument("--min-free-gb",type=float,default=4.0)
    parser.add_argument("--apply",action="store_true")
    parser.add_argument("--confirm-stream-drained",action="store_true")
    parser.add_argument("--current-generation")
    parser.add_argument("--acked-through",type=int)
    args=parser.parse_args()
    if args.apply:
        if not args.confirm_stream_drained and (not args.current_generation or args.acked_through is None):
            raise SystemExit("--apply requires a drained stream or --current-generation with --acked-through")
        result=migrate(args.database,args.retain_hours,args.min_free_gb,stream_drained=args.confirm_stream_drained,
                       current_generation=args.current_generation,acked_through=args.acked_through)
    else:result={**inspect(args.database,args.retain_hours),"status":"dry-run"}
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=="__main__":main()
