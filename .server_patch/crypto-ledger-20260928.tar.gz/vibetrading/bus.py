from __future__ import annotations

import asyncio
import json
import logging
import re
import time
import hashlib
from dataclasses import dataclass
from typing import Any, AsyncIterator, Protocol

from pydantic import BaseModel

from .models import AssetClass, BaseMarketEvent, DataGapEvent, EventType, Signal, Venue, utc_now_ns
from .settings import RuntimeSettings, get_settings

logger = logging.getLogger(__name__)
_MARKET_PREFIXES = ("md.trade.", "md.order_book.", "md.bar_1m.", "md.funding_rate.", "md.open_interest.", "md.participant_flow.")


class EventBus(Protocol):
    async def connect(self, *, initialize: bool = False) -> None: ...
    async def close(self) -> None: ...
    async def publish_market_event(self, event: BaseMarketEvent) -> None: ...
    async def publish_signal(self, signal: Signal) -> None: ...
    async def publish_order_intent(self, intent: Any) -> None: ...
    async def publish_system(self, kind: str, payload: dict[str, Any] | None = None) -> None: ...
    async def subscribe(self, subject: str, durable: str, batch: int = 100) -> AsyncIterator["BusMessage"]: ...
    async def subscribe_batches(self, subject: str, durable: str, batch: int = 100) -> AsyncIterator[list["BusMessage"]]: ...
    async def subscribe_live(self, subject: str = "live.crypto.>") -> AsyncIterator["BusMessage"]: ...


class JsonEncoder(json.JSONEncoder):
    def default(self, obj: Any) -> Any:
        if isinstance(obj, BaseModel):
            return obj.model_dump(mode="json")
        return super().default(obj)


def dumps(data: Any) -> bytes:
    if isinstance(data, BaseModel):
        return data.model_dump_json(exclude_none=False).encode("utf-8")
    return json.dumps(data, ensure_ascii=False, cls=JsonEncoder, separators=(",", ":")).encode("utf-8")


def loads(data: bytes) -> Any:
    return json.loads(data.decode("utf-8"))


def subject_for_event(event: BaseMarketEvent) -> str:
    symbol = re.sub(r"[^A-Z0-9_]+", "_", event.instrument.std_symbol.upper()).strip("_")
    prefix = "crypto" if event.instrument.asset_class == AssetClass.CRYPTO_PERP else "md"
    return ".".join((prefix, event.event_type.value, event.venue.value, event.instrument.asset_class.value, symbol or "UNKNOWN"))


def subject_for_signal(signal: Signal) -> str:
    strategy = re.sub(r"[^A-Z0-9_]+", "_", signal.strategy_id.upper()).strip("_") or "UNKNOWN"
    symbol = re.sub(r"[^A-Z0-9_]+", "_", signal.instrument.std_symbol.upper()).strip("_") or "UNKNOWN"
    return ".".join(("signal", strategy, signal.instrument.venue.value, signal.instrument.asset_class.value, symbol))


def _is_market_subject(subject: str) -> bool:
    return subject == "md.>" or subject.startswith(_MARKET_PREFIXES)


def _is_crypto_subject(subject: str) -> bool:
    return subject == "crypto.>" or subject.startswith("crypto.")


@dataclass
class BusMessage:
    data: dict[str, Any]
    subject: str
    event_id: str
    stream_name: str = ""
    stream_generation: str = ""
    stream_sequence: int | None = None
    delivery_count: int = 1
    _raw: Any = None
    commit_id: str = ""

    def __post_init__(self) -> None:
        if not self.commit_id:
            if self.stream_name and self.stream_generation and self.stream_sequence is not None:
                self.commit_id = f"{self.stream_name}:{self.stream_generation}:{self.stream_sequence}"
            else:
                self.commit_id = self.event_id

    async def ack(self) -> None:
        if self._raw is not None:
            # JetStream ACK is intentionally one-way.  Waiting for a reply
            # for every high-rate market event turns the consumer into a
            # request storm and can itself cause NATS timeouts.
            await self._raw.ack()

    async def nak(self, delay: float = 5.0) -> None:
        if self._raw is not None:
            try:
                await self._raw.nak(delay=delay)
            except TypeError:
                await self._raw.nak()

    async def in_progress(self) -> None:
        if self._raw is not None and hasattr(self._raw, "in_progress"):
            await self._raw.in_progress()


class NatsJetStreamBus:
    """Separate loss-intolerant market WorkQueue from operational fan-out."""

    def __init__(self, settings: RuntimeSettings | None = None) -> None:
        self.settings = settings or get_settings()
        self._nc: Any = None
        self._js: Any = None
        self._market_generation = ""
        # A JetStream control-plane request can briefly lag behind a healthy
        # data plane while the same small disk is being compacted.  Preserve a
        # recent, confirmed stream size so that a single STREAM.INFO timeout
        # does not look like a full stream and pause every collector.
        self._market_usage_ratio: float | None = None
        self._market_usage_checked_at = 0.0

    @property
    def market_stream_name(self) -> str:
        return self.settings.nats.stream_name

    @property
    def operations_stream_name(self) -> str:
        return self.settings.nats.operations_stream_name

    @property
    def crypto_stream_name(self) -> str:
        return "CRYPTO_DATA"

    async def connect(self, *, initialize: bool = False) -> None:
        import nats

        self._nc = await nats.connect(self.settings.nats.url, connect_timeout=5, reconnect_time_wait=1,
                                      max_reconnect_attempts=-1, ping_interval=20, max_outstanding_pings=5,
                                      drain_timeout=5)
        self._js = self._nc.jetstream()
        if initialize:
            await self.initialize_streams()
        try:
            info = await self._js.stream_info(self.market_stream_name)
            self._market_generation = str(getattr(info, "created", "") or self.market_stream_name)
            self._remember_market_usage(info)
        except Exception:
            self._market_generation = ""
        try:
            info = await self._js.stream_info(self.crypto_stream_name)
            self._crypto_generation = str(getattr(info, "created", "") or self.crypto_stream_name)
        except Exception:
            self._crypto_generation = ""

    def _remember_market_usage(self, info: Any) -> float:
        state = getattr(info, "state", None)
        ratio = int(getattr(state, "bytes", 0) or 0) / max(1, int(self.settings.nats.max_bytes))
        self._market_usage_ratio = ratio
        self._market_usage_checked_at = time.monotonic()
        return ratio

    async def initialize_streams(self) -> None:
        if self._js is None:
            raise RuntimeError("NATS JetStream is not connected")
        from nats.js.api import DiscardPolicy, RetentionPolicy, StorageType, StreamConfig

        await self._ensure_stream(StreamConfig(
            name=self.market_stream_name,
            subjects=["md.trade.>", "md.order_book.>", "md.bar_1m.>", "md.funding_rate.>", "md.open_interest.>", "md.participant_flow.>", "md.index_quote.>"],
            retention=RetentionPolicy.WORK_QUEUE, storage=StorageType.FILE,
            max_bytes=int(self.settings.nats.max_bytes), discard=DiscardPolicy.NEW, duplicate_window=120,
        ))
        await self._ensure_stream(StreamConfig(
            name=self.crypto_stream_name,
            subjects=["crypto.trade.>", "crypto.order_book.>", "crypto.funding_rate.>", "crypto.open_interest.>"],
            retention=RetentionPolicy.WORK_QUEUE, storage=StorageType.FILE,
            max_bytes=int(self.settings.env.get("CRYPTO_NATS_MAX_BYTES", str(self.settings.nats.max_bytes))),
            discard=DiscardPolicy.NEW, duplicate_window=120,
        ))
        await self._ensure_stream(StreamConfig(
            name=self.operations_stream_name, subjects=["md.data_gap.>", "crypto.data_gap.>", "signal.>", "order.>", "system.>"],
            retention=RetentionPolicy.LIMITS, storage=StorageType.FILE,
            max_bytes=int(self.settings.nats.operations_max_bytes), discard=DiscardPolicy.OLD, duplicate_window=120,
        ))
        await self.ensure_storage_consumer()
        await self.ensure_crypto_storage_consumer()

    async def ensure_crypto_storage_consumer(self) -> None:
        from nats.js.api import AckPolicy, ConsumerConfig
        wanted = ConsumerConfig(durable_name="crypto-parquet-storage", filter_subject="crypto.>", ack_policy=AckPolicy.EXPLICIT,
                                ack_wait=int(self.settings.nats.ack_wait_seconds), max_ack_pending=int(self.settings.nats.max_ack_pending))
        try:
            current = (await self._js.consumer_info(self.crypto_stream_name, "crypto-parquet-storage")).config
        except Exception as exc:
            if "not found" not in str(exc).lower():
                raise
            await self._js.add_consumer(self.crypto_stream_name, config=wanted)
            return
        if str(current.filter_subject) != "crypto.>" or int(current.max_ack_pending or 0) != int(wanted.max_ack_pending):
            raise RuntimeError("crypto storage consumer policy differs; stop ingestion and migrate explicitly")

    async def _ensure_stream(self, wanted: Any) -> None:
        try:
            current = (await self._js.stream_info(wanted.name)).config
        except Exception:
            await self._js.add_stream(wanted)
            return
        def policy_value(value: Any) -> str:
            return str(getattr(value, "value", value)).lower()

        current_subjects = {str(x) for x in (current.subjects or [])}
        wanted_subjects = {str(x) for x in (wanted.subjects or [])}
        same_non_subject_policy = (
            policy_value(current.retention) == policy_value(wanted.retention)
            and policy_value(current.discard) == policy_value(wanted.discard)
            and policy_value(current.storage) == policy_value(wanted.storage)
        )
        # A planned additive subject migration is safe for the existing
        # WorkQueue and durable consumer.  Subject removal or policy changes
        # remain fail-closed because they could orphan unconsumed messages.
        if not same_non_subject_policy or not current_subjects.issubset(wanted_subjects):
            raise RuntimeError(f"JetStream stream {wanted.name} has incompatible policy; stop ingestion and reset/migrate it explicitly.")
        if current_subjects != wanted_subjects or int(current.max_bytes or 0) != int(wanted.max_bytes):
            await self._js.update_stream(wanted)

    async def ensure_storage_consumer(self) -> None:
        if self._js is None:
            raise RuntimeError("NATS JetStream is not connected")
        from nats.js.api import AckPolicy, ConsumerConfig

        wanted = ConsumerConfig(durable_name="parquet-storage", filter_subject="md.>", ack_policy=AckPolicy.EXPLICIT,
                                ack_wait=int(self.settings.nats.ack_wait_seconds),
                                max_ack_pending=int(self.settings.nats.max_ack_pending))
        try:
            current = (await self._js.consumer_info(self.market_stream_name, "parquet-storage")).config
        except Exception as exc:
            if "not found" not in str(exc).lower():
                raise
            await self._js.add_consumer(self.market_stream_name, config=wanted)
            return
        if str(current.filter_subject) != "md.>" or int(current.max_ack_pending or 0) != int(wanted.max_ack_pending) or int(current.ack_wait or 0) != int(wanted.ack_wait):
            raise RuntimeError("parquet-storage consumer policy differs; reset it explicitly while collectors are stopped.")

    async def reset_storage_consumer_if_empty(self) -> dict[str, int | str]:
        """Recreate the storage durable only after all market data is ACKed.

        This is intentionally stricter than checking consumer pending alone:
        WorkQueue stream messages, pending deliveries, and ACK-pending deliveries
        must all be zero before the durable policy can be changed.
        """
        if self._js is None:
            raise RuntimeError("NATS JetStream is not connected")
        stream_info = await self._js.stream_info(self.market_stream_name)
        try:
            consumer_info = await self._js.consumer_info(self.market_stream_name, "parquet-storage")
        except Exception as exc:
            if "not found" not in str(exc).lower():
                raise
            consumer_info = None
        messages = int(getattr(stream_info.state, "messages", 0) or 0)
        pending = int(getattr(consumer_info, "num_pending", 0) or 0) if consumer_info is not None else 0
        ack_pending = int(getattr(consumer_info, "num_ack_pending", 0) or 0) if consumer_info is not None else 0
        if messages or pending or ack_pending:
            raise RuntimeError(
                "refusing storage consumer reset while MARKET_DATA is not empty: "
                f"messages={messages} pending={pending} ack_pending={ack_pending}"
            )
        if consumer_info is not None:
            await self._js.delete_consumer(self.market_stream_name, "parquet-storage")
        await self.ensure_storage_consumer()
        return {
            "status": "recreated",
            "stream": self.market_stream_name,
            "max_ack_pending": int(self.settings.nats.max_ack_pending),
            "ack_wait_seconds": int(self.settings.nats.ack_wait_seconds),
        }

    async def close(self) -> None:
        if self._nc is not None:
            try:
                await asyncio.wait_for(self._nc.drain(),timeout=5)
            except Exception:
                try:
                    await asyncio.wait_for(self._nc.close(),timeout=2)
                except Exception:
                    logger.warning("timed out while closing NATS connection",exc_info=True)
        self._nc = self._js = None

    async def _publish(self, subject: str, payload: bytes, message_id: str = "") -> None:
        if self._js is None:
            raise RuntimeError("NATS JetStream is not connected")
        await self._js.publish(subject, payload, headers={"Nats-Msg-Id": message_id} if message_id else None, timeout=5)

    async def publish_market_event(self, event: BaseMarketEvent) -> None:
        if event.event_type == EventType.DATA_GAP:
            subject = subject_for_event(event)
            payload = dumps(event)
            await self._publish(subject, payload, event.event_id)
            if event.instrument.asset_class == AssetClass.CRYPTO_PERP and self._nc is not None:
                await self._nc.publish("live." + subject, payload)
            return
        if event.instrument.asset_class == AssetClass.CRYPTO_PERP:
            allowed = event.venue.value in {"binance", "bitget", "bybit"} and event.instrument.std_symbol in {"BTCUSDT", "ETHUSDT", "SOLUSDT"} and event.event_type in {EventType.TRADE, EventType.ORDER_BOOK, EventType.FUNDING_RATE, EventType.OPEN_INTEREST}
        elif (event.instrument.venue == Venue.TOSS and event.event_type == EventType.BAR_1M):
            allowed = (event.provider == "toss" and event.instrument.asset_class == AssetClass.EQUITY
                       and event.instrument.std_symbol in {"TOSS:US:SPY", "TOSS:US:QQQ"})
        elif event.instrument.venue.value in {"hyperliquid", "binance"}:
            allowed = (
                event.event_type in {EventType.ORDER_BOOK, EventType.BAR_1M, EventType.FUNDING_RATE, EventType.OPEN_INTEREST}
                and event.instrument.asset_class == AssetClass.FUTURE
            )
        else:
            allowed = (
                event.event_type in {EventType.TRADE, EventType.ORDER_BOOK, EventType.PARTICIPANT_FLOW}
                and event.instrument.asset_class not in {AssetClass.CRYPTO_SPOT, AssetClass.CRYPTO_PERP}
            )
        if not allowed:
            logger.warning("blocked collection-policy event type=%s instrument=%s", event.event_type.value, event.instrument.key)
            return
        reference_ts = event.source_ts_ns or event.wallclock_ts_ns or event.receive_ts_ns or time.time_ns()
        age = time.time_ns() - int(reference_ts)
        max_age = max(60, int(self.settings.env.get("MARKET_EVENT_MAX_AGE_SECONDS", "172800")))
        skew = max(1, int(self.settings.env.get("MARKET_EVENT_FUTURE_SKEW_SECONDS", "300")))
        if age > max_age * 1_000_000_000 or age < -skew * 1_000_000_000:
            gap = DataGapEvent(instrument=event.instrument, venue=event.venue, provider=event.provider,
                               source_ts_ns=utc_now_ns(), receive_ts_ns=utc_now_ns(), session=event.session,
                               sequence=event.sequence, reason=f"invalid realtime timestamp age_seconds={age // 1_000_000_000}",
                               resync_status="blocked_invalid_timestamp")
            await self._publish(subject_for_event(gap), dumps(gap), gap.event_id)
            return
        subject = subject_for_event(event)
        payload = dumps(event)
        await self._publish(subject, payload, event.event_id)
        # Core NATS delivers a low-latency copy after JetStream accepts the
        # durable message. Parquet commit happens independently downstream.
        # Slow strategy subscribers cannot consume or block the storage WorkQueue.
        if event.instrument.asset_class == AssetClass.CRYPTO_PERP and self._nc is not None and not (event.event_type == EventType.ORDER_BOOK and getattr(event,"fast",None) is False):
            if event.event_type == EventType.ORDER_BOOK and getattr(event,"raw_payload",None) is not None:
                live_data=event.model_dump(mode="json")
                live_data.pop("raw_payload",None)
                await self._nc.publish("live." + subject, dumps(live_data))
            else:
                await self._nc.publish("live." + subject, payload)

    async def publish_signal(self, signal: Signal) -> None:
        await self._publish(subject_for_signal(signal), dumps(signal), signal.signal_id)

    async def publish_order_intent(self, intent: Any) -> None:
        intent_id = str(getattr(intent, "intent_id", "") or (intent.get("intent_id", "") if isinstance(intent, dict) else ""))
        await self._publish("order.intent", dumps(intent), intent_id)

    async def publish_system(self, kind: str, payload: dict[str, Any] | None = None) -> None:
        await self._publish("system." + kind, dumps({"event_type": "system", "kind": kind, "ts_ns": time.time_ns(), **(payload or {})}))

    async def subscribe(self, subject: str, durable: str, batch: int = 100) -> AsyncIterator[BusMessage]:
        async for items in self.subscribe_batches(subject, durable, batch):
            for item in items:
                yield item

    async def subscribe_live(self, subject: str = "live.crypto.>") -> AsyncIterator[BusMessage]:
        if self._nc is None:
            raise RuntimeError("NATS is not connected")
        if not subject.startswith("live.crypto."):
            raise ValueError("only crypto live feed is enabled")
        subscription = await self._nc.subscribe(subject, pending_msgs_limit=256, pending_bytes_limit=8 * 1024 * 1024)
        try:
            async for raw in subscription.messages:
                body = loads(raw.data)
                yield BusMessage(body, raw.subject, str(body.get("event_id") or ""))
        finally:
            await subscription.unsubscribe()

    async def subscribe_batches(self, subject: str, durable: str, batch: int = 100) -> AsyncIterator[list[BusMessage]]:
        if self._js is None:
            raise RuntimeError("NATS JetStream is not connected")
        market = _is_market_subject(subject)
        crypto = _is_crypto_subject(subject)
        if market and durable != "parquet-storage":
            raise RuntimeError("MARKET_DATA is storage-only WorkQueue; live strategies need a separate fan-out feed")
        if crypto and durable != "crypto-parquet-storage":
            raise RuntimeError("CRYPTO_DATA is storage-only WorkQueue")
        if market:
            await self.ensure_storage_consumer()
        if crypto:
            await self.ensure_crypto_storage_consumer()
        stream = self.crypto_stream_name if crypto else self.market_stream_name if market else self.operations_stream_name
        sub = await self._js.pull_subscribe(subject, durable=durable, stream=stream)
        while True:
            try:
                # The server-side fetch timeout normally returns in one
                # second. Keep an outer deadline as well: a stalled control
                # request must not prevent storage from flushing an already
                # durable in-memory batch.
                raw_messages = await asyncio.wait_for(sub.fetch(batch=batch, timeout=1), timeout=2)
            except Exception as exc:
                if "timeout" in exc.__class__.__name__.lower():
                    yield []
                    continue
                raise
            output: list[BusMessage] = []
            for raw in raw_messages:
                body = loads(raw.data)
                try:
                    sequence = int(raw.metadata.sequence.stream)
                except Exception:
                    sequence = None
                try:
                    delivery_count = int(raw.metadata.num_delivered or 1)
                except Exception:
                    delivery_count = 1
                output.append(BusMessage(body, raw.subject, str(body.get("event_id") or ""),
                                         stream if market or crypto else "", self._market_generation if market else str(getattr(self, "_crypto_generation", "")) if crypto else "", sequence, delivery_count, raw))
            yield output

    async def market_stream_usage_ratio(self) -> float:
        if self._js is None:
            return 1.0
        try:
            return self._remember_market_usage(await self._js.stream_info(self.market_stream_name))
        except Exception:
            if self._market_usage_ratio is not None and time.monotonic() - self._market_usage_checked_at <= 60.0:
                return self._market_usage_ratio
            return 1.0

    async def crypto_stream_usage_ratio(self) -> float:
        if self._js is None:
            return 1.0
        try:
            info = await self._js.stream_info(self.crypto_stream_name)
            limit = int(self.settings.env.get("CRYPTO_NATS_MAX_BYTES", str(self.settings.nats.max_bytes)))
            return int(info.state.bytes) / max(1, limit)
        except Exception:
            return 1.0

    async def market_stream_status(self) -> dict[str, int | float]:
        if self._js is None:
            return {"bytes": 0, "messages": 0, "max_bytes": self.settings.nats.max_bytes, "ratio": 1.0}
        info = await self._js.stream_info(self.market_stream_name)
        return {"bytes": int(info.state.bytes), "messages": int(info.state.messages), "max_bytes": self.settings.nats.max_bytes, "ratio": await self.market_stream_usage_ratio()}

    async def crypto_stream_status(self) -> dict[str, int | float]:
        if self._js is None:
            return {"bytes": 0, "messages": 0, "ratio": 1.0}
        info = await self._js.stream_info(self.crypto_stream_name)
        return {"bytes": int(info.state.bytes), "messages": int(info.state.messages),
                "max_bytes": int(self.settings.env.get("CRYPTO_NATS_MAX_BYTES",str(self.settings.nats.max_bytes))),
                "ratio": await self.crypto_stream_usage_ratio()}


class BufferedMarketEventBus:
    """Bounded sharded publisher that keeps WebSocket receive loops responsive.

    A symbol always maps to the same shard, preserving its event order.  Four
    workers overlap JetStream round trips while 128 queued frames / 64 MiB
    provide strict backpressure rather than unbounded memory growth.
    """

    def __init__(self, inner: Any, *, shards: int = 4, max_items: int = 128, max_bytes: int = 64 * 1024 * 1024) -> None:
        self.inner=inner;self.shards=max(1,int(shards));self.max_bytes=max(1,int(max_bytes))
        per_shard=max(1,int(max_items)//self.shards)
        self._queues=[asyncio.Queue(maxsize=per_shard) for _ in range(self.shards)]
        self._workers:list[asyncio.Task[Any]]=[];self._queued_bytes=0;self._condition=asyncio.Condition();self._error:BaseException|None=None
        self._accepted=0;self._published=0;self._failed=0

    @property
    def stats(self)->dict[str,int]:
        return {"accepted":self._accepted,"published":self._published,"failed":self._failed,
                "pending":max(0,self._accepted-self._published-self._failed),"queued_bytes":self._queued_bytes}

    def __getattr__(self,name:str)->Any:return getattr(self.inner,name)

    async def start(self)->None:
        if not self._workers:
            self._workers=[asyncio.create_task(self._worker(queue),name=f"nats-publisher-{index}") for index,queue in enumerate(self._queues)]

    async def publish_market_event(self,event:BaseMarketEvent)->None:
        await self.start();size=len(dumps(event))
        if size>self.max_bytes:raise RuntimeError(f"single market event exceeds publisher byte limit: {size}")
        async with self._condition:
            while self._queued_bytes+size>self.max_bytes:
                self._raise_error();await self._condition.wait()
            self._raise_error();self._queued_bytes+=size
            self._accepted+=1
        key=event.instrument.key.encode("utf-8");index=int.from_bytes(hashlib.sha256(key).digest()[:4],"big")%self.shards
        await self._queues[index].put((event,size))
        self._raise_error()

    async def _worker(self,queue:asyncio.Queue[Any])->None:
        while True:
            event,size=await queue.get()
            try:
                await self.inner.publish_market_event(event)
                self._published+=1
            except asyncio.CancelledError:raise
            except BaseException as exc:
                self._failed+=1
                self._error=exc
            finally:
                async with self._condition:
                    self._queued_bytes=max(0,self._queued_bytes-size);self._condition.notify_all()
                queue.task_done()
            if self._error is not None:return

    def _raise_error(self)->None:
        if self._error is not None:raise RuntimeError(f"buffered NATS publisher failed: {self._error}") from self._error

    async def close(self,timeout_seconds:float=5.0)->None:
        try:
            if self._error is None:
                try:
                    await asyncio.wait_for(asyncio.gather(*(queue.join() for queue in self._queues)),timeout=max(0.1,timeout_seconds))
                except TimeoutError as exc:
                    self._error=RuntimeError(f"publisher drain timed out with {self.stats['pending']} pending events")
            self._raise_error()
        finally:
            for worker in self._workers:worker.cancel()
            await asyncio.gather(*self._workers,return_exceptions=True);self._workers=[]


class InMemoryEventBus:
    def __init__(self) -> None:
        self.messages: list[BusMessage] = []

    async def connect(self, *, initialize: bool = False) -> None:
        del initialize

    async def close(self) -> None:
        return None

    async def publish_market_event(self, event: BaseMarketEvent) -> None:
        if event.event_type == EventType.DATA_GAP:
            pass
        elif event.instrument.asset_class == AssetClass.CRYPTO_PERP:
            if event.venue.value not in {"binance", "bitget", "bybit"} or event.instrument.std_symbol not in {"BTCUSDT", "ETHUSDT", "SOLUSDT"} or event.event_type not in {EventType.TRADE, EventType.ORDER_BOOK, EventType.FUNDING_RATE, EventType.OPEN_INTEREST}:
                return
        elif (event.instrument.venue == Venue.TOSS and event.event_type == EventType.BAR_1M):
            if not (event.provider == "toss" and event.instrument.asset_class == AssetClass.EQUITY
                    and event.instrument.std_symbol in {"TOSS:US:SPY", "TOSS:US:QQQ"}):
                return
        elif event.instrument.venue.value in {"hyperliquid", "binance"}:
            if event.event_type not in {EventType.ORDER_BOOK, EventType.BAR_1M, EventType.FUNDING_RATE, EventType.OPEN_INTEREST} or event.instrument.asset_class != AssetClass.FUTURE:
                return
        elif event.event_type not in {EventType.TRADE, EventType.ORDER_BOOK, EventType.PARTICIPANT_FLOW} or event.instrument.asset_class in {AssetClass.CRYPTO_SPOT, AssetClass.CRYPTO_PERP}:
            return
        self.messages.append(BusMessage(event.model_dump(mode="json"), subject_for_event(event), event.event_id))

    async def publish_signal(self, signal: Signal) -> None:
        self.messages.append(BusMessage(signal.model_dump(mode="json"), subject_for_signal(signal), signal.signal_id))

    async def publish_order_intent(self, intent: Any) -> None:
        body = intent.model_dump(mode="json") if isinstance(intent, BaseModel) else dict(intent)
        self.messages.append(BusMessage(body, "order.intent", str(body.get("intent_id") or "")))

    async def publish_system(self, kind: str, payload: dict[str, Any] | None = None) -> None:
        self.messages.append(BusMessage({"event_type": "system", "kind": kind, **(payload or {})}, "system." + kind, ""))

    async def subscribe(self, subject: str, durable: str, batch: int = 100) -> AsyncIterator[BusMessage]:
        async for items in self.subscribe_batches(subject, durable, batch):
            for item in items:
                yield item

    async def subscribe_batches(self, subject: str, durable: str, batch: int = 100) -> AsyncIterator[list[BusMessage]]:
        del durable
        index = 0
        while True:
            if index < len(self.messages):
                source = self.messages[index:]
                index = len(self.messages)
                prefix = subject[:-1] if subject.endswith(">") else subject
                items = [item for item in source if item.subject.startswith(prefix)][:batch]
                yield items
            else:
                await asyncio.sleep(0.05)
                yield []

    async def market_stream_usage_ratio(self) -> float:
        return 0.0

    async def crypto_stream_usage_ratio(self) -> float:
        return 0.0

    async def subscribe_live(self, subject: str = "live.crypto.>") -> AsyncIterator[BusMessage]:
        index = 0
        while True:
            source = self.messages[index:]
            index = len(self.messages)
            for item in source:
                if item.subject.startswith("crypto."):
                    yield item
            await asyncio.sleep(0.05)
