from __future__ import annotations

import asyncio
import time
from dataclasses import replace
from types import SimpleNamespace

from vibetrading.health import touch
from vibetrading.settings import RuntimeSettings
from vibetrading.telegram import TelegramController


def _controller(tmp_path):
    env = tmp_path / ".env"
    env.write_text(
        f"VIBETRADING_DATA_ROOT={tmp_path.as_posix()}\n"
        "TELEGRAM_BOT_TOKEN=test-token\nTELEGRAM_USER_ID=123\n",
        encoding="utf-8",
    )
    return TelegramController(RuntimeSettings.from_env(env))


def test_status_does_not_claim_configured_crypto_is_collecting(tmp_path):
    bot = _controller(tmp_path)
    for name in ("collectors", "storage", "maintenance"):
        touch(bot.settings, name, detail={"providers": ["binance"]} if name == "collectors" else {})
    touch(bot.settings, "collectors-binance", detail={"phase": "publishing"})
    message = bot._compact_status()
    assert "서비스 3/3 정상" in message
    assert "메모리" in message and "저장공간" in message
    assert "Binance: 중지" in message
    assert "Bitget: 중지" in message
    assert "Bybit: 중지" in message
    assert "실제 수집 종목: 없음" in message
    assert len(message) < 500


def test_status_reports_only_recent_symbols(tmp_path):
    bot = _controller(tmp_path)
    for name in ("collectors", "storage", "maintenance"):
        touch(bot.settings, name, detail={"providers": ["binance"]} if name == "collectors" else {})
    touch(bot.settings, "collectors-binance", detail={"phase": "publishing"})
    touch(bot.settings, "crypto-collectors", detail={"providers": ["binance-perp", "bitget-perp", "bybit-perp"]})
    now = time.time_ns()
    touch(bot.settings, "collectors-binance-perp", detail={"phase": "publishing", "symbol_last_seen_ns": {"BTCUSDT": now}})
    touch(bot.settings, "collectors-bitget-perp", detail={"phase": "publishing", "symbol_last_seen_ns": {"ETHUSDT": now - 180_000_000_000}})
    touch(bot.settings, "collectors-bybit-perp", state="error", detail={"phase": "retrying"})
    message = bot._compact_status()
    assert "Binance: BTCUSDT" in message
    assert "📊 서버 주의" in message
    assert "Bitget: 연결됨 · 종목 확인 중" in message
    assert "Bybit: 오류" in message
    assert "실제 수집 종목: BTCUSDT" in message
    assert "ETHUSDT" not in message


def test_status_command_and_crypto_alert_deduplication(tmp_path):
    bot = _controller(tmp_path)
    sent = []

    async def fake_send(_session, chat_id, message):
        sent.append((chat_id, message))

    bot._send = fake_send

    async def exercise():
        await bot._handle(None, {"message": {"from": {"id": 123}, "chat": {"id": 123}, "text": "status"}})
        await bot._crypto_issue(None, "bitget-perp", "WebSocket error")
        await bot._crypto_issue(None, "bitget-perp", "WebSocket error")
        await bot._crypto_recovered(None, "bitget-perp")

    asyncio.run(exercise())
    assert sent[0][1].startswith("📊 서버")
    assert len(sent) == 3
    assert "Bitget 선물 수집 오류" in sent[1][1]
    assert "Bitget 선물 수집 복구" in sent[2][1]


def test_status_warns_when_crypto_storage_is_down(tmp_path, monkeypatch):
    # Exercise storage state independently of the test PC's available RAM.
    monkeypatch.setattr('vibetrading.telegram.psutil.virtual_memory',
                        lambda: SimpleNamespace(total=4 * 1024**3, available=2 * 1024**3))
    bot = _controller(tmp_path)
    for name in ("collectors", "storage", "maintenance"):
        touch(bot.settings, name, detail={"providers": ["binance"]} if name == "collectors" else None)
    touch(bot.settings, "collectors-binance")
    providers = ("binance-perp", "bitget-perp", "bybit-perp")
    touch(bot.settings, "crypto-collectors", detail={"providers": providers})
    seen = {symbol: time.time_ns() for symbol in ("BTCUSDT", "ETHUSDT", "SOLUSDT")}
    for provider in providers:
        touch(bot.settings, f"collectors-{provider}", detail={"phase": "publishing", "symbol_last_seen_ns": seen})
    assert "📊 서버 주의" in bot._compact_status()
    assert "코인 저장 오류 · 보관 오류" in bot._compact_status()

    crypto_settings = replace(bot.settings, state_dir=bot.settings.data_root / "crypto_state")
    touch(crypto_settings, "crypto-storage")
    touch(crypto_settings, "maintenance")
    assert "📊 서버 정상" in bot._compact_status()
